// DOM Elements
const audioPlayer = document.getElementById('audioPlayer');
const youtubePlayer = document.getElementById('youtubePlayer');
const playBtn = document.getElementById('playBtn');
const playIcon = document.getElementById('playIcon');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const progressRange = document.getElementById('progressRange');
const progress = document.getElementById('progress');
const currentTimeEl = document.getElementById('currentTime');
const durationEl = document.getElementById('duration');
const volumeRange = document.getElementById('volumeRange');
const volumeValue = document.getElementById('volumeValue');
const albumArt = document.getElementById('albumArt');
const songTitle = document.getElementById('songTitle');
const songArtist = document.getElementById('songArtist');
const playlistItems = document.getElementById('playlistItems');
const autoplayToggle = document.getElementById('autoplayToggle');

// State
let currentSongIndex = 0;
let isPlaying = false;
let playlist = []; // runtime playlist; starts empty—user must search
let favorites = []; // favorite songs from localStorage
let showingFavorites = false;
let youtubeIframe = null;
let isYouTubePlayerReady = false;

// DOM elements for search (added in updated HTML)
const searchInput = document.getElementById('searchInput');
const searchBtn = document.getElementById('searchBtn');
const searchResults = document.getElementById('searchResults');
const searchResultsList = document.getElementById('searchResultsList');
const closeResults = document.getElementById('closeResults');

// DOM elements for favorites
const favoritesList = document.getElementById('favoritesList');
const toggleFavoritesBtn = document.getElementById('toggleFavorites');

// Initialize
document.addEventListener('DOMContentLoaded', () => {
  loadFavorites(); // Load favorites from localStorage
  initPlaylist(); // populate empty list on page load
  setVolume();
  setupFavoritesEventListeners();
});

// Initialize Playlist Display
function initPlaylist() {
  playlistItems.innerHTML = '';
  playlist.forEach((song, index) => {
    const li = document.createElement('li');
    li.className = index === 0 ? 'active' : '';
    const isFav = isFavorite(song.id);
    li.innerHTML = `
            <div class="playlist-item-title">
                <span class="title">${song.title}</span>
                <span class="duration">${formatTime(song.duration)}</span>
            </div>
            <div class="playlist-item-artist">${song.artist}</div>
            <button class="heart-btn ${isFav ? 'favorited' : ''}" data-id="${song.id}" title="Add to favorites">♡</button>
        `;

    // Heart button click
    li.querySelector('.heart-btn').addEventListener('click', (e) => {
      e.stopPropagation();
      if (isFavorite(song.id)) {
        removeFromFavorites(song.id);
      } else {
        addToFavorites(song);
      }
    });

    li.addEventListener('click', () => {
      currentSongIndex = index;
      loadSong(index);
      play();
    });
    playlistItems.appendChild(li);
  });
}

// Load Song
function loadSong(index) {
  const song = playlist[index];
  audioPlayer.src = song.src;

  // Add fallback source if available
  audioPlayer.onerror = () => {
    console.warn('Primary audio source failed, trying fallback...');
    if (song.fallbackSrc) {
      audioPlayer.src = song.fallbackSrc;
      audioPlayer.load();
    } else {
      alert('Failed to play audio. Try a different song.');
    }
  };

  if (!audioPlayer.src) {
    alert('No song loaded. Please select a song from the playlist.');
    return;
  }

  songTitle.textContent = song.title;
  songArtist.textContent = song.artist;
  albumArt.src = song.albumArt;
  durationEl.textContent = formatTime(song.duration);
  updateActivePlaylistItem();
}

// Update Active Playlist Item
function updateActivePlaylistItem() {
  document.querySelectorAll('.playlist li').forEach((item, index) => {
    item.classList.toggle('active', index === currentSongIndex);
  });
}

// Format Time
function formatTime(seconds) {
  if (isNaN(seconds)) return '0:00';
  const minutes = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${minutes}:${secs.toString().padStart(2, '0')}`;
}

// Play
function play() {
  if (!audioPlayer.src) {
    alert('No song loaded. Please select a song from the playlist.');
    return;
  }

  audioPlayer.play().catch(err => {
    console.error('Playback error:', err);
    alert('Failed to play audio. Try a different song.');
  });

  isPlaying = true;
  playIcon.textContent = '⏸';
  playBtn.title = 'Pause';
}

// Pause
function pause() {
  audioPlayer.pause();
  isPlaying = false;
  playIcon.textContent = '▶';
  playBtn.title = 'Play';
}

// Toggle Play/Pause
playBtn.addEventListener('click', () => {
  isPlaying ? pause() : play();
});

// Next Song
nextBtn.addEventListener('click', () => {
  currentSongIndex = (currentSongIndex + 1) % playlist.length;
  loadSong(currentSongIndex);
  play();
});

// Previous Song
prevBtn.addEventListener('click', () => {
  currentSongIndex = (currentSongIndex - 1 + playlist.length) % playlist.length;
  loadSong(currentSongIndex);
  play();
});

// Update Progress Bar
audioPlayer.addEventListener('timeupdate', () => {
  if (audioPlayer.duration) {
    const progressPercent = (audioPlayer.currentTime / audioPlayer.duration) * 100;
    progress.style.width = progressPercent + '%';
    progressRange.value = progressPercent;
    currentTimeEl.textContent = formatTime(audioPlayer.currentTime);
  }
});

// Seek Progress
progressRange.addEventListener('input', (e) => {
  const seekTime = (e.target.value / 100) * audioPlayer.duration;
  audioPlayer.currentTime = seekTime;
});

// Update Duration
audioPlayer.addEventListener('loadedmetadata', () => {
  durationEl.textContent = formatTime(audioPlayer.duration);
});

// Set Volume
function setVolume() {
  const volume = volumeRange.value / 100;
  audioPlayer.volume = volume;
  volumeValue.textContent = volumeRange.value + '%';
}

volumeRange.addEventListener('input', setVolume);

// Autoplay Next Song
audioPlayer.addEventListener('ended', () => {
  if (autoplayToggle.checked) {
    nextBtn.click();
  } else {
    pause();
  }
});

// Hybrid Search - Archive for specific genres, iTunes fallback
async function searchSongs(term) {
  if (!term || term.trim().length === 0) return;

  try {
    let results = [];

    // Define genres that should use Archive only (full-length music)
    const archiveOnlyGenres = ['reggae', 'reggea', 'classical', 'jazz', 'hip hop', 'hip-hop', 'beethoven', 'mozart', 'bach', 'chopin', 'brahms', 'symphony', 'concerto', 'sonata'];
    const useArchiveOnly = archiveOnlyGenres.some(genre => term.toLowerCase().includes(genre));

    // Try Archive FIRST for specified genres
    if (useArchiveOnly) {
      try {
        const archiveUrl = `https://archive.org/advancedsearch.php?q=${encodeURIComponent(term)}&fl=identifier,title,creator,length_seconds&output=json&rows=30`;
        const archiveRes = await fetch(archiveUrl);
        const archiveData = await archiveRes.json();

        if (archiveData.response?.docs && archiveData.response.docs.length > 0) {
          const archiveResults = await Promise.all(
            archiveData.response.docs
              .filter(r => r.identifier)
              .slice(0, 30)
              .map(async (r) => {
                try {
                  // Fetch metadata to find actual audio files
                  const metaRes = await fetch(`https://archive.org/metadata/${r.identifier}`);
                  const metaData = await metaRes.json();

                  // Find first playable audio file
                  const files = metaData.files || [];
                  const audioFile = files.find(f =>
                    f.name.endsWith('.mp3') ||
                    f.name.endsWith('.m4a') ||
                    f.name.endsWith('.flac') ||
                    f.name.endsWith('.wav') ||
                    f.name.endsWith('.ogg')
                  );

                  const audioUrl = audioFile
                    ? `https://archive.org/download/${r.identifier}/${audioFile.name}`
                    : `https://archive.org/download/${r.identifier}/`;

                  return {
                    id: r.identifier,
                    title: r.title || 'Unknown',
                    artist: r.creator ? (Array.isArray(r.creator) ? r.creator[0] : r.creator) : 'Unknown Artist',
                    duration: parseInt(r.length_seconds) || 0,
                    src: audioUrl,
                    fallbackSrc: null,
                    albumArt: `https://archive.org/services/img/${r.identifier}`,
                    source: 'Archive (Full-Length)'
                  };
                } catch (err) {
                  // If metadata fetch fails, return basic URL
                  console.warn('Metadata fetch failed for', r.identifier);
                  return {
                    id: r.identifier,
                    title: r.title || 'Unknown',
                    artist: r.creator ? (Array.isArray(r.creator) ? r.creator[0] : r.creator) : 'Unknown Artist',
                    duration: parseInt(r.length_seconds) || 0,
                    src: `https://archive.org/download/${r.identifier}/`,
                    fallbackSrc: null,
                    albumArt: `https://archive.org/services/img/${r.identifier}`,
                    source: 'Archive (Full-Length)'
                  };
                }
              })
          );

          if (archiveResults.length > 0) {
            results = archiveResults;
          }
        }
      } catch (err) {
        console.warn('Archive search failed:', err);
      }
    }

    // For other genres or if Archive has no results, try iTunes (only if not an archive-only genre)
    if (results.length === 0 && !useArchiveOnly) {
      try {
        const itunesUrl = `https://itunes.apple.com/search?term=${encodeURIComponent(term)}&media=music&entity=song&limit=25`;
        const itunesRes = await fetch(itunesUrl);
        const itunesData = await itunesRes.json();

        if (itunesData.results && itunesData.results.length > 0) {
          const itunesResults = itunesData.results
            .filter(r => r.previewUrl)
            .slice(0, 25)
            .map((r, idx) => ({
              id: `itunes-${r.trackId || idx}`,
              title: r.trackName || 'Unknown',
              artist: r.artistName || 'Unknown Artist',
              duration: r.trackTimeMillis ? Math.floor(r.trackTimeMillis / 1000) : 0,
              src: r.previewUrl,
              fallbackSrc: null,
              albumArt: r.artworkUrl100 ? r.artworkUrl100.replace('100x100', '300x300') : 'https://via.placeholder.com/300',
              source: 'iTunes (30-sec Preview)'
            }));
          results = itunesResults;
        }
      } catch (err) {
        console.warn('iTunes search failed:', err);
      }
    }

    if (results.length > 0) {
      displaySearchResults(results);
    } else {
      alert('No songs found. Try: "beethoven", "hip hop", "reggae", "jazz", or any artist name.');
    }
  } catch (err) {
    console.error('Search error', err);
    alert('Search failed. Check your internet connection.');
  }
}

function displaySearchResults(results) {
  searchResultsList.innerHTML = '';
  results.forEach(song => {
    const li = document.createElement('li');
    li.className = 'search-result-item';
    li.innerHTML = `
      <div class="search-result-info">
        <div class="search-result-title">${song.title}</div>
        <div class="search-result-artist">${song.artist}</div>
        <div style="font-size: 10px; color: #aaa; margin-top: 2px;">${formatTime(song.duration)} • ${song.source}</div>
      </div>
      <button class="add-btn" data-song='${JSON.stringify(song).replace(/'/g, "&apos;")}'>Add</button>
    `;

    const addBtn = li.querySelector('.add-btn');
    addBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      playlist.push(song);
      initPlaylist();
      alert(`Added "${song.title}" to playlist!`);
    });

    searchResultsList.appendChild(li);
  });

  searchResults.style.display = 'flex';
}

if (closeResults) {
  closeResults.addEventListener('click', () => {
    searchResults.style.display = 'none';
    searchResultsList.innerHTML = '';
  });
}

// Wire up search button/enter
if (searchBtn) {
  searchBtn.addEventListener('click', () => {
    searchSongs(searchInput.value);
  });
}

if (searchInput) {
  searchInput.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') searchSongs(searchInput.value);
  });
}

// Keyboard Controls
document.addEventListener('keydown', (e) => {
  // Don't trigger player controls when typing in search box
  if (document.activeElement === searchInput) return;

  if (e.code === 'Space') {
    e.preventDefault();
    playBtn.click();
  } else if (e.code === 'ArrowRight') {
    nextBtn.click();
  } else if (e.code === 'ArrowLeft') {
    prevBtn.click();
  }
});

// ===== FAVORITES FUNCTIONALITY =====

// Load favorites from localStorage
function loadFavorites() {
  const saved = localStorage.getItem('musicPlayerFavorites');
  favorites = saved ? JSON.parse(saved) : [];
}

// Save favorites to localStorage
function saveFavorites() {
  localStorage.setItem('musicPlayerFavorites', JSON.stringify(favorites));
}

// Add song to favorites
function addToFavorites(song) {
  if (!favorites.find(f => f.id === song.id)) {
    favorites.push(song);
    saveFavorites();
    updateFavoritesDisplay();
    updatePlaylistHearts();
  }
}

// Remove song from favorites
function removeFromFavorites(songId) {
  favorites = favorites.filter(f => f.id !== songId);
  saveFavorites();
  updateFavoritesDisplay();
  updatePlaylistHearts();
}

// Check if song is in favorites
function isFavorite(songId) {
  return favorites.some(f => f.id === songId);
}

// Display favorites list
function updateFavoritesDisplay() {
  if (favorites.length === 0) {
    favoritesList.innerHTML = '<p style="text-align: center; color: #999;">No favorites yet</p>';
    return;
  }

  favoritesList.innerHTML = favorites.map(song => `
    <div class="favorite-item" data-id="${song.id}">
      <div class="favorite-info">
        <div class="favorite-title">${song.title}</div>
        <div class="favorite-artist">${song.artist}</div>
      </div>
      <div class="favorite-actions">
        <button class="play-fav-btn" data-id="${song.id}" title="Play">▶</button>
        <button class="remove-fav-btn" data-id="${song.id}" title="Remove">✕</button>
      </div>
    </div>
  `).join('');

  // Add event listeners to favorite items
  document.querySelectorAll('.play-fav-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const songId = btn.dataset.id;
      const song = favorites.find(f => f.id === songId);
      if (song) {
        audioPlayer.src = song.src;
        songTitle.textContent = song.title;
        songArtist.textContent = song.artist;
        albumArt.src = song.albumArt;
        durationEl.textContent = formatTime(song.duration);
        play();
      }
    });
  });

  document.querySelectorAll('.remove-fav-btn').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      removeFromFavorites(btn.dataset.id);
    });
  });
}

// Toggle favorites panel visibility
function setupFavoritesEventListeners() {
  toggleFavoritesBtn.addEventListener('click', () => {
    const isHidden = favoritesList.style.display === 'none';
    favoritesList.style.display = isHidden ? 'block' : 'none';
    toggleFavoritesBtn.textContent = isHidden ? 'Hide' : 'Show';
  });
}

// Update heart icons in playlist
function updatePlaylistHearts() {
  document.querySelectorAll('.heart-btn').forEach(btn => {
    const songId = btn.dataset.id;
    btn.classList.toggle('favorited', isFavorite(songId));
  });
}
