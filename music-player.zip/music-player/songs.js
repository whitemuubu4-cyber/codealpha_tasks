// Playlist Data
// Songs are now fetched from iTunes API via search functionality.
// This array is kept for backwards compatibility but is no longer used.
const songs = [];
