# Image Gallery - JavaScript Code Documentation

## Overview
This is a fully-featured, responsive image gallery with a lightbox modal, category filtering, search functionality, and multiple image effects. The code is extensively commented for easy understanding and maintenance.

---

## Table of Contents
1. [Project Features](#project-features)
2. [File Structure](#file-structure)
3. [JavaScript Code Explanation](#javascript-code-explanation)
4. [Data Structure](#data-structure)
5. [Core Functions](#core-functions)
6. [Event Listeners](#event-listeners)
7. [Keyboard Shortcuts](#keyboard-shortcuts)
8. [Browser Compatibility](#browser-compatibility)
9. [Performance Considerations](#performance-considerations)
10. [How to Customize](#how-to-customize)

---

## Project Features

✨ **Gallery Features:**
- ✅ Dynamic image gallery with responsive grid layout
- ✅ Lightbox modal with full navigation
- ✅ Category-based filtering (All, Family, Lodge, Garden)
- ✅ Search functionality with real-time filtering
- ✅ Multiple image filters (Original, Grayscale, Sepia, Blur)
- ✅ Smooth animations and transitions
- ✅ Hover effects on gallery items
- ✅ Keyboard navigation support
- ✅ Scroll-to-top button
- ✅ Mobile responsive design
- ✅ Cross-browser compatible

---

## File Structure

```
Image Gallery/
├── index.html          # HTML structure and markup
├── index.css           # Styling and responsive design
├── gallery.js          # Main JavaScript functionality
├── README.md           # This file
└── Images/             # Image folder with all gallery images
    ├── IMG-20241018-WA0011.jpg
    ├── IMG-20241018-WA0016.jpg
    ├── ... (25 images total)
    └── IMG-20250204-WA0006.jpg
```

---

## JavaScript Code Explanation

### Section 1: Data Management

#### `galleryData` Array
```javascript
const galleryData = [
  { name: 'IMG-20241018-WA0011', path: 'Images/IMG-20241018-WA0011.jpg', 
    category: 'family', description: 'Family Gathering' },
  // ... more images
];
```

**Purpose:** Central data store containing all image metadata

**Properties:**
- `name`: Image filename (used for search)
- `path`: Image file location (used for src attribute)
- `category`: Image category ('all', 'family', 'lodge', 'garden')
- `description`: Human-readable title (displayed in lightbox)

**Why it matters:** 
- Separates data from presentation
- Makes it easy to add/remove images
- Enables filtering and search functionality
- Centralizes image metadata

---

### Section 2: State Variables

```javascript
let currentCategory = 'all';      // Current filter category
let currentFilter = 'original';   // Current effect filter
let displayedImages = [...galleryData]; // Filtered image array
let currentLightboxIndex = 0;     // Lightbox navigation index
```

**Explanation:**
- `currentCategory`: Tracks which category filter is active
- `currentFilter`: Tracks which visual effect is applied
- `displayedImages`: Result of applying category + search filters (copies original data)
- `currentLightboxIndex`: Keeps track of which image is shown in lightbox

**Why mutable variables?** They need to change when user interacts with gallery

---

### Section 3: DOM Caching

```javascript
const DOM = {
  galleryContainer: document.getElementById('galleryContainer'),
  lightbox: document.getElementById('lightbox'),
  lightboxImage: document.getElementById('lightboxImage'),
  // ... more elements
};
```

**Purpose:** Cache frequently accessed DOM elements for performance

**Benefits:**
- Avoids repeated DOM queries (faster execution)
- Cleaner code organization
- Easier to refactor if HTML IDs change
- Improves performance significantly

---

## Core Functions

### 1. `renderGallery()`

**What it does:**
- Clears previous gallery items
- Creates new gallery item elements for each image
- Applies current filter effects
- Adds click handlers to open lightbox

**How it works:**
```javascript
displayedImages.forEach((image, index) => {
  const galleryItem = document.createElement('div');
  // ... create image, overlay, and click handler
  DOM.galleryContainer.appendChild(galleryItem);
});
```

**Key points:**
- Runs whenever filters change or page loads
- Uses `forEach()` to iterate over filtered images
- Creates DOM elements dynamically (not hardcoded in HTML)
- Each gallery item gets a unique index for lightbox navigation

---

### 2. `applyFilterToImage(imgElement)`

**What it does:**
- Removes old filter classes from image
- Applies new filter class based on `currentFilter`

**Available Filters:**
```
original   → No CSS filter applied
grayscale  → 100% grayscale effect (CSS filter: grayscale(100%))
sepia      → Vintage sepia effect (CSS filter: sepia(100%))
blur       → Blurred effect (CSS filter: blur(8px))
```

**Implementation:**
```javascript
if (currentFilter === 'grayscale') {
  imgElement.classList.add('grayscale-filter');
}
// CSS class handles the actual filter
```

---

### 3. `filterGallery()`

**What it does:**
- Combines category filter + search filter
- Updates `displayedImages` array
- Re-renders the gallery

**Logic Flow:**
1. Get search term from input field
2. Filter by category: `image.category === currentCategory`
3. Filter by search: match image name or description
4. Both filters must pass (AND logic)
5. Re-render gallery with results

**Example:**
```javascript
let filtered = galleryData.filter(image => {
  const matchesCategory = currentCategory === 'all' || 
                         image.category === currentCategory;
  const matchesSearch = image.name.toLowerCase().includes(searchTerm) || 
                       image.description.toLowerCase().includes(searchTerm);
  return matchesCategory && matchesSearch; // Both must be true
});
```

---

### 4. `openLightbox(index)`

**What it does:**
- Opens the lightbox modal
- Displays the clicked image
- Sets up for navigation

**Process:**
```javascript
function openLightbox(index) {
  currentLightboxIndex = index;      // Remember which image
  displayLightboxImage();             // Load and display it
  DOM.lightbox.classList.add('active'); // Show modal
  document.body.style.overflow = 'hidden'; // Disable scrolling
}
```

**Why disable scrolling?** Prevents confusing UX where background scrolls while modal is open

---

### 5. `displayLightboxImage()`

**What it does:**
- Updates lightbox with current image
- Updates counter (1/25)
- Updates title/description
- Handles circular navigation

**Circular Navigation:**
```javascript
if (currentLightboxIndex < 0) {
  currentLightboxIndex = displayedImages.length - 1; // Go to last
} else if (currentLightboxIndex >= displayedImages.length) {
  currentLightboxIndex = 0; // Go to first
}
```

This allows endless navigation - clicking next on the last image shows the first.

---

### 6. `nextImage()` & `prevImage()`

**What they do:**
- Increment or decrement `currentLightboxIndex`
- Call `displayLightboxImage()` to update display

**Code:**
```javascript
function nextImage() {
  currentLightboxIndex++;    // Next index
  displayLightboxImage();    // Update display
}

function prevImage() {
  currentLightboxIndex--;    // Previous index
  displayLightboxImage();    // Update display
}
```

**Circular navigation:** Handled in `displayLightboxImage()`

---

## Event Listeners

### 1. Category Navigation
```javascript
DOM.navItems.forEach(item => {
  item.addEventListener('click', function() {
    // Remove 'active' from all, add to this one
    currentCategory = this.dataset.category;
    filterGallery();
  });
});
```

**How it works:**
- Each nav item has `data-category="family"` (or other)
- Clicking updates `currentCategory`
- Calls `filterGallery()` to update display

---

### 2. Image Filters
```javascript
DOM.filterBtns.forEach(btn => {
  btn.addEventListener('click', function() {
    currentFilter = this.dataset.filter;
    renderGallery();
  });
});
```

**How it works:**
- Each filter button has `data-filter="grayscale"` (or other)
- Clicking updates `currentFilter`
- Calls `renderGallery()` to apply new filter to all images

---

### 3. Search Input
```javascript
DOM.searchInput.addEventListener('input', function() {
  filterGallery();
});
```

**Triggering:** 'input' event fires as user types (not just on Enter)

---

### 4. Lightbox Controls
```javascript
DOM.lightboxClose.addEventListener('click', closeLightbox);
DOM.nextBtn.addEventListener('click', nextImage);
DOM.prevBtn.addEventListener('click', prevImage);

// Close when clicking outside image
DOM.lightbox.addEventListener('click', function(e) {
  if (e.target === DOM.lightbox) closeLightbox();
});
```

---

### 5. Keyboard Navigation
```javascript
document.addEventListener('keydown', function(e) {
  if (!DOM.lightbox.classList.contains('active')) return;
  
  switch(e.key) {
    case 'ArrowRight': nextImage(); break;
    case 'ArrowLeft': prevImage(); break;
    case 'Escape': closeLightbox(); break;
  }
});
```

**Smart:** Only works when lightbox is open (using `contains('active')`)

---

## Keyboard Shortcuts

When lightbox is open:

| Key | Action |
|-----|--------|
| `→` (Right Arrow) | Next image |
| `←` (Left Arrow) | Previous image |
| `Esc` | Close lightbox |

---

## Browser Compatibility

✅ **Supported:**
- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+
- Mobile browsers (iOS Safari, Chrome Mobile)

**Uses:** Modern JavaScript (ES6) but no bleeding-edge features

---

## Performance Considerations

### 1. DOM Caching
```javascript
const DOM = { /* cached elements */ };
```
- Faster than repeated `document.getElementById()` calls
- ~1000x faster per query when cached

### 2. Event Delegation
Gallery uses direct event listeners on elements rather than relying on event bubbling for simple tasks - this is clearer and prevents accidental event conflicts.

### 3. CSS Filters vs JavaScript
```javascript
// CSS handles the actual filtering (faster)
img.classList.add('grayscale-filter');
// CSS file contains: .grayscale-filter { filter: grayscale(100%); }
```
CSS filters are GPU-accelerated (much faster than canvas manipulation)

### 4. Image Lazy Loading (Optional Enhancement)
Current implementation loads all images immediately. For 1000+ images, consider adding lazy loading:
```javascript
img.loading = 'lazy'; // HTML5 native lazy loading
```

---

## How to Customize

### Add a New Image

1. Add image file to `Images/` folder
2. Add entry to `galleryData` array in `gallery.js`:

```javascript
{ 
  name: 'IMG-20250205-WA0001', 
  path: 'Images/IMG-20250205-WA0001.jpg', 
  category: 'family',           // Change category as needed
  description: 'New Family Photo' 
}
```

### Add a New Category

1. Update `galleryData` - use new category name
2. Add nav item to HTML:
```html
<li class="nav-item" data-category="newcategory">New Category</li>
```

### Change Color Scheme

Edit `index.css` - look for color variables:
```css
background-color: rgb(167, 42, 4);  /* Change these values */
```

### Modify Filter Effects

Edit CSS filters in `index.css`:
```css
.grayscale-filter {
  filter: grayscale(100%);  /* Change percentage or add more effects */
}
```

### Add More Filter Types

1. Add button to HTML:
```html
<button class="filter-btn" data-filter="saturate">Saturate</button>
```

2. Add CSS class:
```css
.saturate-filter {
  filter: saturate(200%);
}
```

3. Handle in JavaScript (automatic - already checks `data-filter`)

---

## Code Quality Notes

✅ **Best Practices Followed:**
- Extensive comments explaining every section
- Meaningful variable names (`currentLightboxIndex` not `i`)
- Separated concerns (data, UI, logic)
- DRY principle (Don't Repeat Yourself)
- Event listener organization
- DOM caching for performance
- Proper error handling with fallbacks

📝 **Variable Naming Convention:**
- `DOM` - cached DOM elements
- `gallery` - global export for debugging
- `current*` - state variables
- Functions use `camelCase`
- Constants use `UPPER_CASE` (none here as data is dynamic)

---

## Debugging

### Enable Debug Logging

In browser console:
```javascript
gallery.logState()  // Shows current gallery state
```

### Common Issues

**Images not loading:**
- Check image paths are correct
- Verify `Images/` folder exists
- Check browser console for 404 errors

**Lightbox not opening:**
- Check `gallery.js` is loaded (no 404 in console)
- Verify lightbox HTML element exists with correct ID

**Filters not working:**
- Ensure CSS file is loaded
- Check `data-filter` attributes match CSS class names
- Verify `.css` file has filter classes defined

---

## Future Enhancement Ideas

💡 **Possible Additions:**
- [ ] Image upload functionality
- [ ] Ratings/favorites system
- [ ] Social media sharing buttons
- [ ] Full-screen lightbox mode
- [ ] Image slideshow/autoplay
- [ ] Touch gesture support (swipe)
- [ ] EXIF data display
- [ ] Image rotation/zoom in lightbox
- [ ] Pagination instead of loading all at once
- [ ] API integration for dynamic images

---

## License & Credits

This gallery was built with vanilla JavaScript (no frameworks) for maximum compatibility and performance.

**Icon Library:** Font Awesome 6.4.0 (for magnifying glass, arrows, etc.)

---

## Quick Start

1. **Add Images:** Place images in `Images/` folder
2. **Register Images:** Add entries to `galleryData` in `gallery.js`
3. **Open `index.html`** in a web browser
4. **Test:** Click images, use filters, test keyboard navigation

**That's it!** No build process, no dependencies - just pure HTML, CSS, and JavaScript.

---

**Last Updated:** January 2026
**Version:** 1.0
**Author:** AI Assistant (GitHub Copilot)
