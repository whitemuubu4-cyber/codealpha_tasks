/**
 * ================================================
 * ADVANCED IMAGE GALLERY WITH LIGHTBOX & FILTERS
 * ================================================
 * 
 * This comprehensive gallery system includes:
 * - Dynamic image loading from the Images folder
 * - Category filtering
 * - Image search functionality
 * - Advanced filter effects (grayscale, sepia, blur, brightness, contrast)
 * - Lightbox modal with navigation
 * - Image zoom controls in lightbox
 * - Full-screen mode
 * - Download and share functionality
 * - Favorites/bookmarks system
 * - Dark/Light theme toggle
 * - Grid view toggle
 * - Undo/Redo for filters
 * - Responsive design support
 * - Smooth animations and transitions
 */

// ================================================
// DATA MANAGEMENT
// ================================================

/**
 * Gallery configuration object containing all image metadata
 * Each image includes: name, path, category, and description
 */
const galleryData = [
  { name: 'basketball', path: 'Images/basketball.jpeg', category: 'sports', description: 'Basketball Game' },
  { name: 'footbal1', path: 'Images/footbal1.jpeg', category: 'sports', description: 'Football Action' },
  { name: 'football2', path: 'Images/football2.jpeg', category: 'sports', description: 'Football Match' },
  { name: 'football3', path: 'Images/football3.jpeg', category: 'sports', description: 'Football Play' },
  { name: 'football4', path: 'Images/football4.jpeg', category: 'sports', description: 'Football Game' },
  { name: 'football5', path: 'Images/football5jpeg.jpeg', category: 'sports', description: 'Football Action' },
  { name: 'football7', path: 'Images/football7.jpeg', category: 'sports', description: 'Football Match' },
  { name: 'football8', path: 'Images/football8.jpeg', category: 'sports', description: 'Football Play' },
  { name: 'lodge-bar', path: 'Images/lodge-bar.jpeg', category: 'lodge', description: 'Lodge Bar' },
  { name: 'lodge-one', path: 'Images/lodge-one.jpeg', category: 'lodge', description: 'Lodge Area' },
  { name: 'lodge3', path: 'Images/lodge3.jpeg', category: 'lodge', description: 'Lodge Room' },
  { name: 'lodge4', path: 'Images/lodge4.jpeg', category: 'lodge', description: 'Lodge Space' },
  { name: 'lodge5', path: 'Images/lodge5.jpeg', category: 'lodge', description: 'Lodge Interior' },
  { name: 'lodge6', path: 'Images/lodge6.jpeg', category: 'lodge', description: 'Lodge View' },
  { name: 'lodge7', path: 'Images/lodge7.jpeg', category: 'lodge', description: 'Lodge Exterior' },
  { name: 'lodge8', path: 'Images/lodge8.jpeg', category: 'lodge', description: 'Lodge Entrance' },
  { name: 'lodge9', path: 'Images/lodge9.jpeg', category: 'lodge', description: 'Lodge Deck' },
  { name: 'spinach', path: 'Images/spinach.jpeg', category: 'garden', description: 'Spinach Plants' },
  { name: 'spinach1', path: 'Images/spinach1.jpeg', category: 'garden', description: 'Garden Spinach' },
  { name: 'tomatoes2', path: 'Images/tomatoes2jpeg.jpeg', category: 'garden', description: 'Tomato Plants' },
  { name: 'cabbage', path: 'Images/cabbage.jpeg', category: 'garden', description: 'Cabbage Plants' },
  { name: 'pumkin', path: 'Images/pumkin.jpeg', category: 'garden', description: 'Pumpkin Patch' },
  { name: 'rape', path: 'Images/rape.jpeg', category: 'garden', description: 'Garden Vegetables' },
  { name: 'tomato2', path: 'Images/tomato2.jpeg', category: 'garden', description: 'Fresh Tomatoes' }
];

// ================================================
// STATE VARIABLES
// ================================================

let currentCategory = 'all';
let currentFilter = 'original';
let displayedImages = [...galleryData];
let currentLightboxIndex = 0;
let currentZoom = 1;
let darkTheme = localStorage.getItem('darkTheme') === 'true';
let favorites = JSON.parse(localStorage.getItem('favorites')) || [];
let filterHistory = ['original'];
let filterHistoryIndex = 0;
let gridView = localStorage.getItem('gridView') === 'true';

// ================================================
// DOM ELEMENTS CACHING
// ================================================

const DOM = {
  galleryContainer: document.getElementById('galleryContainer'),
  lightbox: document.getElementById('lightbox'),
  lightboxImage: document.getElementById('lightboxImage'),
  lightboxImageContainer: document.getElementById('lightboxImageContainer'),
  lightboxClose: document.querySelector('.lightbox-close'),
  prevBtn: document.getElementById('prevBtn'),
  nextBtn: document.getElementById('nextBtn'),
  currentImageIndex: document.getElementById('currentImageIndex'),
  totalImages: document.getElementById('totalImages'),
  lightboxTitle: document.getElementById('lightboxTitle'),
  lightboxMetadata: document.getElementById('lightboxMetadata'),
  searchInput: document.getElementById('searchInput'),
  scrollToTopBtn: document.getElementById('scrollToTopBtn'),
  navItems: document.querySelectorAll('.nav-item'),
  filterBtns: document.querySelectorAll('.filter-btn'),
  themeToggleBtn: document.getElementById('themeToggleBtn'),
  gridToggleBtn: document.getElementById('gridToggleBtn'),
  favoritesBtn: document.getElementById('favoritesBtn'),
  undoFilterBtn: document.getElementById('undoFilterBtn'),
  redoFilterBtn: document.getElementById('redoFilterBtn'),
  shareModal: document.getElementById('shareModal'),
  favoritesModal: document.getElementById('favoritesModal'),
  favoriteLightboxBtn: document.getElementById('favoriteLightboxBtn'),
  downloadBtn: document.getElementById('downloadBtn'),
  shareBtn: document.getElementById('shareBtn'),
  fullscreenBtn: document.getElementById('fullscreenBtn'),
  zoomInBtn: document.getElementById('zoomInBtn'),
  zoomOutBtn: document.getElementById('zoomOutBtn'),
  zoomResetBtn: document.getElementById('zoomResetBtn'),
  favoriteCount: document.querySelector('.favorite-count')
};

// ================================================
// INITIALIZATION
// ================================================

document.addEventListener('DOMContentLoaded', function () {
  console.log('Advanced Gallery initialized');

  // Apply saved theme
  if (darkTheme) {
    document.body.classList.add('dark-theme');
    DOM.themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
  }

  renderGallery();
  setupEventListeners();
  updateTotalImageCount();
  updateFavoriteCount();
  startHeaderSlideshow();
  applyLazyLoading();
});

// ================================================
// LAZY LOADING
// ================================================

function applyLazyLoading() {
  const images = document.querySelectorAll('.gallery-item img');
  const imageObserver = new IntersectionObserver((entries, observer) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const img = entry.target;
        img.src = img.dataset.src || img.src;
        observer.unobserve(img);
      }
    });
  });

  images.forEach(img => imageObserver.observe(img));
}

// ================================================
// GALLERY RENDERING
// ================================================

/**
 * Render gallery items to the DOM based on current filters
 * Creates gallery item elements dynamically for each image
 * Includes click handlers for lightbox activation
 */
function renderGallery() {
  // Clear existing gallery items
  DOM.galleryContainer.innerHTML = '';

  // Display message if no images match current filters
  if (displayedImages.length === 0) {
    DOM.galleryContainer.innerHTML = '<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: #999;">No images found</div>';
    return;
  }

  // Create and append gallery items
  displayedImages.forEach((image, index) => {
    // Create the gallery item container
    const galleryItem = document.createElement('div');
    galleryItem.className = 'gallery-item';
    galleryItem.dataset.index = index;

    // Check if favorited
    if (favorites.some(fav => fav.includes(image.name))) {
      galleryItem.classList.add('favorited');
    }

    // Create the image element
    const img = document.createElement('img');
    img.src = image.path;
    img.alt = image.description;

    // Apply current filter effect to the image
    applyFilterToImage(img);

    // Create overlay with magnifying glass icon
    const overlay = document.createElement('div');
    overlay.className = 'gallery-overlay';
    overlay.innerHTML = '<i class="fas fa-search-plus overlay-icon"></i>';

    // Create favorite badge
    const favoriteBadge = document.createElement('div');
    favoriteBadge.className = 'favorite-badge';
    favoriteBadge.innerHTML = '<i class="fas fa-heart"></i>';

    // Append elements and add click event
    galleryItem.appendChild(img);
    galleryItem.appendChild(overlay);
    galleryItem.appendChild(favoriteBadge);
    galleryItem.addEventListener('click', () => openLightbox(index));

    // Add favorite toggle on badge click
    favoriteBadge.addEventListener('click', (e) => {
      e.stopPropagation();
      toggleFavorite(image.path);
    });

    DOM.galleryContainer.appendChild(galleryItem);
  });
}

/**
 * Apply current filter effect to an image element
 * Supports: original, grayscale, sepia, blur, brightness, contrast
 * 
 * @param {HTMLImageElement} imgElement - The image element to apply filter to
 */
// Note: Moved to advanced features section - see line ~694

// ================================================
// FILTERING & SEARCH
// ================================================

/**
 * Filter gallery by category and search term
 * Combines both category and search filters
 * Updates displayedImages array and re-renders gallery
 */
function filterGallery() {
  const searchTerm = DOM.searchInput.value.toLowerCase();

  // Filter images based on category
  let filtered = galleryData.filter(image => {
    const matchesCategory = currentCategory === 'all' || image.category === currentCategory;
    const matchesSearch = image.name.toLowerCase().includes(searchTerm) ||
      image.description.toLowerCase().includes(searchTerm);

    return matchesCategory && matchesSearch;
  });

  displayedImages = filtered;
  renderGallery();
  updateTotalImageCount();
}

/**
 * Update the total image count displayed in lightbox
 * Called when gallery is filtered or gallery is rendered
 */
function updateTotalImageCount() {
  DOM.totalImages.textContent = displayedImages.length;
}

// ================================================
// LIGHTBOX FUNCTIONALITY
// ================================================

/**
 * Open lightbox modal and display image at given index
 * Shows the lightbox and initializes navigation
 * 
 * @param {number} index - Index of the image to display in displayedImages array
 */
function openLightbox(index) {
  currentLightboxIndex = index;
  displayLightboxImage();
  DOM.lightbox.classList.add('active');
  document.body.style.overflow = 'hidden'; // Prevent scrolling while lightbox is open
}

/**
 * Close lightbox modal
 * Hides the lightbox and restores page scrolling
 */
function closeLightbox() {
  DOM.lightbox.classList.remove('active');
  document.body.style.overflow = 'auto'; // Restore scrolling
}

/**
 * Display image at current lightbox index
 * Updates image source, counter, and description
 * Handles circular navigation (wraps around at ends)
 */
function displayLightboxImage() {
  // Handle circular navigation
  if (currentLightboxIndex < 0) {
    currentLightboxIndex = displayedImages.length - 1;
  } else if (currentLightboxIndex >= displayedImages.length) {
    currentLightboxIndex = 0;
  }

  const image = displayedImages[currentLightboxIndex];

  // Update lightbox with current image
  DOM.lightboxImage.src = image.path;
  DOM.lightboxTitle.textContent = image.description;
  DOM.currentImageIndex.textContent = currentLightboxIndex + 1;

  // Update metadata
  const now = new Date();
  DOM.lightboxMetadata.textContent = `Category: ${image.category} | Viewed: ${now.toLocaleDateString()}`;

  // Reset zoom
  resetZoom();

  // Update favorite button
  updateLightboxFavoriteBadge();

  // Animate image entry
  DOM.lightboxImage.style.animation = 'none';
  setTimeout(() => {
    DOM.lightboxImage.style.animation = 'imageSlideIn 0.3s ease';
  }, 10);
}

/**
 * Navigate to next image in lightbox
 */
function nextImage() {
  currentLightboxIndex++;
  displayLightboxImage();
}

/**
 * Navigate to previous image in lightbox
 */
function prevImage() {
  currentLightboxIndex--;
  displayLightboxImage();
}

// ================================================
// EVENT LISTENERS
// ================================================

/**
 * Setup all event listeners for the gallery
 * Includes: category navigation, filters, search, lightbox controls, keyboard
 */
function setupEventListeners() {
  // Hamburger Menu Toggle
  const hamburgerBtn = document.getElementById('hamburgerBtn');
  const navMenu = document.getElementById('navMenu');

  if (hamburgerBtn && navMenu) {
    hamburgerBtn.addEventListener('click', function (e) {
      e.preventDefault();
      e.stopPropagation();
      navMenu.classList.toggle('active');
      console.log('Hamburger clicked. Menu active:', navMenu.classList.contains('active'));
    });

    // Close menu when clicking outside
    document.addEventListener('click', function (e) {
      if (!e.target.closest('.hamburger') && !e.target.closest('.nav-menu')) {
        navMenu.classList.remove('active');
      }
    });
  }

  // Close menu when a nav item is clicked
  DOM.navItems.forEach(item => {
    item.addEventListener('click', function () {
      // Close the hamburger menu
      if (navMenu) {
        navMenu.classList.remove('active');
      }

      // Remove active class from all nav items
      DOM.navItems.forEach(nav => nav.classList.remove('active'));
      // Add active class to clicked item
      this.classList.add('active');

      // Update current category and filter gallery
      currentCategory = this.dataset.category;
      filterGallery();
    });
  });

  // Image Filters
  DOM.filterBtns.forEach(btn => {
    btn.addEventListener('click', function () {
      // Remove active class from all filter buttons
      DOM.filterBtns.forEach(button => button.classList.remove('active'));
      // Add active class to clicked button
      this.classList.add('active');

      // Update current filter and re-render gallery
      currentFilter = this.dataset.filter;
      addToFilterHistory(currentFilter);
      renderGallery();
    });
  });

  // Theme Toggle
  DOM.themeToggleBtn.addEventListener('click', toggleTheme);

  // Favorites Button
  DOM.favoritesBtn.addEventListener('click', showFavoritesModal);

  // Filter Undo/Redo
  DOM.undoFilterBtn.addEventListener('click', undoFilter);
  DOM.redoFilterBtn.addEventListener('click', redoFilter);

  // Search Functionality
  DOM.searchInput.addEventListener('input', function () {
    filterGallery();
  });

  // Lightbox Controls
  DOM.lightboxClose.addEventListener('click', closeLightbox);
  DOM.nextBtn.addEventListener('click', nextImage);
  DOM.prevBtn.addEventListener('click', prevImage);

  // Lightbox Toolbar Buttons
  DOM.favoriteLightboxBtn.addEventListener('click', function () {
    const image = displayedImages[currentLightboxIndex];
    toggleFavorite(image.path);
  });

  DOM.downloadBtn.addEventListener('click', downloadImage);
  DOM.shareBtn.addEventListener('click', showShareModal);
  DOM.fullscreenBtn.addEventListener('click', toggleFullscreen);
  DOM.zoomInBtn.addEventListener('click', () => zoomImage(0.2));
  DOM.zoomOutBtn.addEventListener('click', () => zoomImage(-0.2));
  DOM.zoomResetBtn.addEventListener('click', resetZoom);

  // Share Modal
  document.getElementById('shareLink').addEventListener('click', () => shareImage('link'));
  document.getElementById('shareFacebook').addEventListener('click', () => shareImage('facebook'));
  document.getElementById('shareTwitter').addEventListener('click', () => shareImage('twitter'));
  document.getElementById('sharePinterest').addEventListener('click', () => shareImage('pinterest'));

  // Modal Closes
  document.querySelectorAll('.modal-close').forEach(btn => {
    btn.addEventListener('click', function () {
      this.closest('.modal').classList.remove('active');
    });
  });

  document.querySelectorAll('.modal').forEach(modal => {
    modal.addEventListener('click', function (e) {
      if (e.target === this) {
        this.classList.remove('active');
      }
    });
  });

  // Close lightbox when clicking outside the image
  DOM.lightbox.addEventListener('click', function (e) {
    if (e.target === DOM.lightbox) {
      closeLightbox();
    }
  });

  // Keyboard Navigation in Lightbox
  document.addEventListener('keydown', function (e) {
    // Only handle keyboard if lightbox is open
    if (!DOM.lightbox.classList.contains('active')) return;

    switch (e.key) {
      case 'ArrowRight':
        nextImage();
        break;
      case 'ArrowLeft':
        prevImage();
        break;
      case 'Escape':
        closeLightbox();
        break;
      case '+':
      case '=':
        zoomImage(0.2);
        break;
      case '-':
        zoomImage(-0.2);
        break;
    }
  });

  // Scroll to Top Button
  window.addEventListener('scroll', toggleScrollToTopButton);
  DOM.scrollToTopBtn.addEventListener('click', scrollToTop);

  updateFilterButtons();
}

// ================================================
// SCROLL TO TOP FUNCTIONALITY
// ================================================

/**
 * Toggle visibility of scroll-to-top button based on scroll position
 * Button appears when user scrolls down 300px
 */
function toggleScrollToTopButton() {
  if (window.scrollY > 300) {
    DOM.scrollToTopBtn.classList.add('show');
  } else {
    DOM.scrollToTopBtn.classList.remove('show');
  }
}

/**
 * Smooth scroll to top of page
 * Uses requestAnimationFrame for smooth animation
 */
function scrollToTop() {
  const scrollHeight = window.scrollY;
  const scrollStep = scrollHeight / 20; // 20 frames for smooth scroll

  function scroll() {
    if (window.scrollY > 0) {
      window.scrollBy(0, -scrollStep);
      requestAnimationFrame(scroll);
    }
  }

  scroll();
}

// ================================================
// HELPER FUNCTIONS
// ================================================

/**
 * Log gallery state for debugging purposes
 * Shows current filters and displayed images
 */
function logGalleryState() {
  console.log('Gallery State:', {
    totalImages: galleryData.length,
    displayedImages: displayedImages.length,
    currentCategory: currentCategory,
    currentFilter: currentFilter,
    currentLightboxIndex: currentLightboxIndex
  });
}

// ================================================
// HEADER SLIDESHOW FUNCTIONALITY
// ================================================

/**
 * Start the header image slideshow
 * Rotates through 4 images every 5 seconds
 * Creates smooth fade transitions between images
 */
let currentSlideIndex = 0;
let slideshowInterval;
let isAutoPlayActive = true;

function startHeaderSlideshow() {
  // Get all slide elements
  const slides = document.querySelectorAll('.slide');

  // If no slides found, exit
  if (slides.length === 0) return;

  // Show the first slide
  showSlide(0);
  updateIndicators();

  // Setup slide control buttons
  const prevSlideBtn = document.getElementById('prevSlideBtn');
  const nextSlideBtn = document.getElementById('nextSlideBtn');
  const playPauseBtn = document.getElementById('playPauseBtn');
  const indicators = document.querySelectorAll('.indicator');

  // Previous slide button
  if (prevSlideBtn) {
    prevSlideBtn.addEventListener('click', () => {
      stopAutoPlay();
      currentSlideIndex--;
      if (currentSlideIndex < 0) {
        currentSlideIndex = slides.length - 1;
      }
      showSlide(currentSlideIndex);
      updateIndicators();
    });
  }

  // Next slide button
  if (nextSlideBtn) {
    nextSlideBtn.addEventListener('click', () => {
      stopAutoPlay();
      currentSlideIndex++;
      if (currentSlideIndex >= slides.length) {
        currentSlideIndex = 0;
      }
      showSlide(currentSlideIndex);
      updateIndicators();
    });
  }

  // Indicator click handlers
  indicators.forEach((indicator, index) => {
    indicator.addEventListener('click', () => {
      stopAutoPlay();
      currentSlideIndex = index;
      showSlide(currentSlideIndex);
      updateIndicators();
    });
  });

  // Start automatic slideshow
  startAutoPlay();
}

/**
 * Start automatic slide rotation
 */
function startAutoPlay() {
  isAutoPlayActive = true;
  slideshowInterval = setInterval(() => {
    const slides = document.querySelectorAll('.slide');
    currentSlideIndex++;
    if (currentSlideIndex >= slides.length) {
      currentSlideIndex = 0; // Loop back to first slide
    }
    showSlide(currentSlideIndex);
    updateIndicators();
  }, 5000);
}

/**
 * Stop automatic slide rotation
 */
function stopAutoPlay() {
  isAutoPlayActive = false;
  clearInterval(slideshowInterval);
}

/**
 * Display slide at given index with smooth transition
 * 
 * @param {number} index - Index of slide to display
 */
function showSlide(index) {
  const slides = document.querySelectorAll('.slide');

  // Hide all slides
  slides.forEach(slide => slide.classList.remove('active'));

  // Show the selected slide
  if (slides[index]) {
    slides[index].classList.add('active');
  }
}

/**
 * Update slide indicator dots to show active slide
 */
function updateIndicators() {
  const indicators = document.querySelectorAll('.indicator');
  indicators.forEach((indicator, index) => {
    indicator.classList.remove('active');
    if (index === currentSlideIndex) {
      indicator.classList.add('active');
    }
  });
}

// Export for debugging (optional)
window.gallery = {
  logState: logGalleryState,
  openLightbox: openLightbox,
  closeLightbox: closeLightbox
};

// ================================================
// ADVANCED FEATURES
// ================================================

/**
 * Apply filter class to image with additional filters
 */
function applyFilterToImage(imgElement) {
  imgElement.classList.remove('grayscale-filter', 'sepia-filter', 'blur-filter', 'brightness-filter', 'contrast-filter');

  if (currentFilter === 'grayscale') {
    imgElement.classList.add('grayscale-filter');
  } else if (currentFilter === 'sepia') {
    imgElement.classList.add('sepia-filter');
  } else if (currentFilter === 'blur') {
    imgElement.classList.add('blur-filter');
  } else if (currentFilter === 'brightness') {
    imgElement.classList.add('brightness-filter');
  } else if (currentFilter === 'contrast') {
    imgElement.classList.add('contrast-filter');
  }
}

/**
 * THEME TOGGLE - Dark/Light mode
 */
function toggleTheme() {
  darkTheme = !darkTheme;
  localStorage.setItem('darkTheme', darkTheme);

  if (darkTheme) {
    document.body.classList.add('dark-theme');
    DOM.themeToggleBtn.innerHTML = '<i class="fas fa-sun"></i>';
  } else {
    document.body.classList.remove('dark-theme');
    DOM.themeToggleBtn.innerHTML = '<i class="fas fa-moon"></i>';
  }
}

/**
 * FAVORITES MANAGEMENT
 */
function toggleFavorite(imagePath) {
  const index = favorites.indexOf(imagePath);
  if (index === -1) {
    favorites.push(imagePath);
  } else {
    favorites.splice(index, 1);
  }
  localStorage.setItem('favorites', JSON.stringify(favorites));
  updateFavoriteCount();
  updateGalleryFavoriteBadges();
  updateLightboxFavoriteBadge();
}

function updateFavoriteCount() {
  DOM.favoriteCount.textContent = favorites.length;
}

function updateGalleryFavoriteBadges() {
  const items = document.querySelectorAll('.gallery-item');
  items.forEach(item => {
    const img = item.querySelector('img');
    if (img && favorites.includes(img.src)) {
      item.classList.add('favorited');
    } else {
      item.classList.remove('favorited');
    }
  });
}

function updateLightboxFavoriteBadge() {
  if (DOM.lightbox.classList.contains('active')) {
    const currentImagePath = displayedImages[currentLightboxIndex].path;
    if (favorites.some(fav => fav.includes(displayedImages[currentLightboxIndex].name))) {
      DOM.favoriteLightboxBtn.innerHTML = '<i class="fas fa-heart"></i>';
    } else {
      DOM.favoriteLightboxBtn.innerHTML = '<i class="far fa-heart"></i>';
    }
  }
}

function showFavoritesModal() {
  const modal = DOM.favoritesModal;
  const favoritesGrid = document.getElementById('favoritesGrid');

  if (favorites.length === 0) {
    favoritesGrid.innerHTML = '<div class="no-favorites">No favorites yet. Click the heart icon to add images!</div>';
  } else {
    favoritesGrid.innerHTML = favorites.map((favPath, idx) => {
      const image = galleryData.find(img => img.path === favPath || favPath.includes(img.name));
      return image ? `
        <div class="favorite-item" data-path="${favPath}">
          <img src="${image.path}" alt="${image.description}">
          <button class="favorite-remove" data-idx="${idx}">
            <i class="fas fa-trash"></i>
          </button>
        </div>
      ` : '';
    }).join('');

    document.querySelectorAll('.favorite-remove').forEach(btn => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const idx = parseInt(btn.dataset.idx);
        favorites.splice(idx, 1);
        localStorage.setItem('favorites', JSON.stringify(favorites));
        showFavoritesModal();
        updateFavoriteCount();
        updateGalleryFavoriteBadges();
      });
    });

    document.querySelectorAll('.favorite-item').forEach(item => {
      item.addEventListener('click', () => {
        const image = galleryData.find(img => item.dataset.path.includes(img.name));
        if (image) {
          const idx = displayedImages.findIndex(img => img.name === image.name);
          if (idx !== -1) {
            openLightbox(idx);
          }
        }
      });
    });
  }

  modal.classList.add('active');
}

/**
 * DOWNLOAD IMAGE
 */
function downloadImage() {
  const image = displayedImages[currentLightboxIndex];
  const link = document.createElement('a');
  link.href = image.path;
  link.download = `${image.name}.jpeg`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

/**
 * SHARE IMAGE
 */
function showShareModal() {
  DOM.shareModal.classList.add('active');
}

function shareImage(platform) {
  const image = displayedImages[currentLightboxIndex];
  const url = window.location.href;
  const title = `Check out this ${image.description}!`;

  let shareUrl = '';
  switch (platform) {
    case 'facebook':
      shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`;
      break;
    case 'twitter':
      shareUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`;
      break;
    case 'pinterest':
      shareUrl = `https://pinterest.com/pin/create/button/?url=${encodeURIComponent(url)}&description=${encodeURIComponent(title)}`;
      break;
    case 'link':
      copyToClipboard(url);
      return;
  }

  if (shareUrl) {
    window.open(shareUrl, '_blank', 'width=600,height=400');
  }
}

function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    const notification = document.getElementById('copyNotification');
    notification.textContent = '✓ Link copied to clipboard!';
    notification.style.display = 'block';
    setTimeout(() => {
      notification.style.display = 'none';
    }, 2000);
  });
}

/**
 * ZOOM CONTROLS IN LIGHTBOX
 */
function zoomImage(factor) {
  currentZoom += factor;
  currentZoom = Math.max(1, Math.min(currentZoom, 4));
  DOM.lightboxImage.style.transform = `scale(${currentZoom})`;
}

function resetZoom() {
  currentZoom = 1;
  DOM.lightboxImage.style.transform = 'scale(1)';
}

/**
 * FULLSCREEN MODE
 */
function toggleFullscreen() {
  if (!document.fullscreenElement) {
    DOM.lightbox.requestFullscreen().catch(err => {
      console.log('Fullscreen request failed:', err);
    });
  } else {
    document.exitFullscreen();
  }
}

/**
 * FILTER HISTORY (UNDO/REDO)
 */
function addToFilterHistory(filter) {
  filterHistory = filterHistory.slice(0, filterHistoryIndex + 1);
  filterHistory.push(filter);
  filterHistoryIndex = filterHistory.length - 1;
  updateFilterButtons();
}

function undoFilter() {
  if (filterHistoryIndex > 0) {
    filterHistoryIndex--;
    currentFilter = filterHistory[filterHistoryIndex];
    DOM.filterBtns.forEach(btn => btn.classList.remove('active'));
    document.querySelector(`[data-filter="${currentFilter}"]`).classList.add('active');
    renderGallery();
    updateFilterButtons();
  }
}

function redoFilter() {
  if (filterHistoryIndex < filterHistory.length - 1) {
    filterHistoryIndex++;
    currentFilter = filterHistory[filterHistoryIndex];
    DOM.filterBtns.forEach(btn => btn.classList.remove('active'));
    document.querySelector(`[data-filter="${currentFilter}"]`).classList.add('active');
    renderGallery();
    updateFilterButtons();
  }
}

function updateFilterButtons() {
  DOM.undoFilterBtn.disabled = filterHistoryIndex <= 0;
  DOM.redoFilterBtn.disabled = filterHistoryIndex >= filterHistory.length - 1;
}
