# Personal Portfolio Website

A modern, responsive portfolio website built with **HTML**, **CSS**, and **JavaScript**. 
Showcase your skills, projects, resume, and contact information with a clean, professional design.

## 📁 Project Structure

```
portfolio/
├── index.html       # Main HTML structure
├── styles.css       # Complete styling and animations
├── script.js        # JavaScript functionality and interactivity
└── README.md        # Project documentation
```

## 🎯 Features

### ✨ Design & Layout
- **Responsive Design** - Mobile-first approach with breakpoints for all devices
- **Modern Gradient UI** - Beautiful gradient colors and smooth transitions
- **Clean Navigation** - Fixed navbar with smooth scroll links
- **Professional Sections**:
  - Hero/Banner section with call-to-action
  - About me with statistics
  - Skills showcase with progress bars
  - Project portfolio with cards
  - Contact form and information
  - Professional footer

### 🎬 Animations & Effects
- **Fade-in animations** - Elements animate as they enter the viewport
- **Hover effects** - Interactive feedback on buttons, links, and cards
- **Smooth scrolling** - CSS-enabled smooth page scrolling
- **Parallax effect** - Background elements move during scroll
- **Progress bar animations** - Skill bars animate to show proficiency
- **Floating elements** - Animated background shapes

### 💻 JavaScript Functionality
- **Smooth scroll navigation** - Jump to sections without page reload
- **Form validation** - Email validation and error handling
- **Intersection Observer** - Trigger animations when elements come into view
- **Active nav indicator** - Highlights current section in navigation
- **Alert system** - Toast notifications for user feedback
- **Keyboard navigation** - Arrow keys to scroll between sections
- **Parallax scrolling** - Dynamic background movement

### 📱 Responsive Features
- **Mobile-optimized** - Works perfectly on phones, tablets, and desktops
- **Flexible grid layouts** - Uses CSS Grid and Flexbox
- **Readable typography** - Font sizes adjust for each breakpoint
- **Touch-friendly** - Buttons and links are appropriately sized

---

## 📋 HTML Documentation

### Overview
The `index.html` file contains the semantic structure of the portfolio website. 
It's organized into logical sections with proper HTML5 semantic tags.

### File Structure

#### Navigation Bar
```html
<nav class="navbar">
    <div class="nav-container">
        <div class="logo">JD</div>
        <ul class="nav-menu">
            <li><a href="#home" class="nav-link">Home</a></li>
            <li><a href="#about" class="nav-link">About</a></li>
            <li><a href="#skills" class="nav-link">Skills</a></li>
            <li><a href="#projects" class="nav-link">Projects</a></li>
            <li><a href="#contact" class="nav-link">Contact</a></li>
        </ul>
    </div>
</nav>
```

**Purpose**: Fixed navigation bar that stays at the top during scrolling. 
Links have smooth scroll behavior handled by JavaScript.

**Key Elements**:
- `.navbar` - Fixed container for navigation
- `.logo` - Brand/initials display
- `.nav-menu` - List of navigation links
- `.nav-link` - Individual navigation links

#### Hero Section
```html
<section id="home" class="hero">
    <div class="hero-content">
        <h1 class="hero-title">Hi, I'm John Doe</h1>
        <p class="hero-subtitle">Full Stack Developer & Creative Designer</p>
        <p class="hero-description">I build beautiful, responsive websites...</p>
        <a href="#projects" class="cta-button">View My Work</a>
    </div>
    <div class="hero-background"></div>
</section>
```

**Purpose**: Welcome section with introduction and call-to-action button.

**Key Elements**:
- `#home` - Section ID for navigation anchor
- `.hero-title` - Main heading with gradient text
- `.cta-button` - Call-to-action button
- `.hero-background` - Animated background with floating shapes

#### About Section
```html
<section id="about" class="about">
    <div class="container">
        <h2 class="section-title">About Me</h2>
        <div class="about-content">
            <div class="about-text">
                <!-- Biographical text -->
                <p>I'm a passionate developer...</p>
            </div>
            <div class="about-stats">
                <div class="stat">
                    <h3>50+</h3>
                    <p>Projects Completed</p>
                </div>
                <!-- More stats -->
            </div>
        </div>
    </div>
</section>
```

**Purpose**: Introduce yourself with background, achievements, and key statistics.

**Key Elements**:
- `.about-text` - Biographical information
- `.about-stats` - Achievement cards with numbers
- `.stat` - Individual statistic display

#### Skills Section
```html
<section id="skills" class="skills">
    <div class="container">
        <h2 class="section-title">My Skills</h2>
        <div class="skills-grid">
            <div class="skill-card">
                <h3>HTML & CSS</h3>
                <div class="skill-bar">
                    <div class="skill-progress" style="width: 95%"></div>
                </div>
                <p>95%</p>
            </div>
            <!-- More skill cards -->
        </div>
    </div>
</section>
```

**Purpose**: Display technical skills with visual progress indicators.

**Key Elements**:
- `.skill-card` - Individual skill container
- `.skill-bar` - Outer progress bar
- `.skill-progress` - Animated progress indicator
- Inline `width` style - Determines skill proficiency level

**How to Add Skills**:
1. Copy a `.skill-card` block
2. Update the `<h3>` with skill name
3. Change the `width` percentage in `.skill-progress`
4. Update the proficiency percentage text

#### Projects Section
```html
<section id="projects" class="projects">
    <div class="container">
        <h2 class="section-title">My Projects</h2>
        <div class="projects-grid">
            <div class="project-card">
                <div class="project-image" style="background: linear-gradient(...)"></div>
                <h3>E-Commerce Platform</h3>
                <p>A full-stack e-commerce solution...</p>
                <div class="project-tags">
                    <span class="tag">React</span>
                    <span class="tag">Node.js</span>
                </div>
                <a href="#" class="project-link">View Project →</a>
            </div>
            <!-- More project cards -->
        </div>
    </div>
</section>
```

**Purpose**: Showcase your best projects with descriptions and technologies used.

**Key Elements**:
- `.project-card` - Individual project container
- `.project-image` - Visual representation (use gradients or real images)
- `.project-tags` - Technology tags
- `.project-link` - Link to full project details

**How to Add Projects**:
1. Copy a `.project-card` block
2. Update project title and description
3. Add relevant technology tags
4. Update the project link URL

#### Contact Section
```html
<section id="contact" class="contact">
    <div class="container">
        <h2 class="section-title">Get In Touch</h2>
        <p class="contact-subtitle">Have a project in mind? Let's work together!</p>
        
        <div class="contact-content">
            <form class="contact-form">
                <div class="form-group">
                    <input type="text" placeholder="Your Name" required>
                </div>
                <div class="form-group">
                    <input type="email" placeholder="Your Email" required>
                </div>
                <div class="form-group">
                    <textarea placeholder="Your Message" rows="5" required></textarea>
                </div>
                <button type="submit" class="submit-btn">Send Message</button>
            </form>

            <div class="contact-info">
                <div class="info-item">
                    <h3>Email</h3>
                    <p><a href="mailto:john@example.com">john@example.com</a></p>
                </div>
                <div class="info-item">
                    <h3>Phone</h3>
                    <p><a href="tel:+1234567890">+1 (234) 567-890</a></p>
                </div>
                <div class="social-links">
                    <a href="#" class="social-icon">LinkedIn</a>
                    <a href="#" class="social-icon">GitHub</a>
                </div>
            </div>
        </div>
    </div>
</section>
```

**Purpose**: Allow visitors to contact you and provide communication channels.

**Key Elements**:
- `.contact-form` - Email form with validation
- `.form-group` - Input wrapper for styling
- `.contact-info` - Email, phone, location, social links
- `.social-links` - Social media connections

### Semantic HTML5 Tags Used
- `<nav>` - Navigation bar
- `<section>` - Content sections
- `<h1>, <h2>, <h3>` - Proper heading hierarchy
- `<form>` - Contact form
- `<footer>` - Page footer

### Accessibility Features
- Semantic HTML structure
- Proper heading hierarchy
- Form input labels (via placeholders)
- Descriptive link text
- Color contrast compliance

---

## 🎨 CSS Documentation

### Overview
The `styles.css` file contains all styling, animations, and responsive design rules. 
It uses modern CSS features like CSS Grid, Flexbox, Gradients, and CSS Custom Properties (variables).

### CSS Custom Properties (Variables)

Located at the root level for easy customization:

```css
:root {
    --primary-color: #667eea;      /* Main brand color (purple-blue) */
    --secondary-color: #764ba2;    /* Secondary gradient color */
    --accent-color: #f5576c;       /* Accent color (pink) */
    --text-dark: #2d3748;          /* Dark text color */
    --text-light: #718096;         /* Light text color */
    --bg-light: #f7fafc;           /* Light background */
    --white: #ffffff;              /* White background */
    --shadow: 0 10px 30px rgba(0, 0, 0, 0.1);        /* Large shadow */
    --shadow-sm: 0 4px 6px rgba(0, 0, 0, 0.07);      /* Small shadow */
    --transition: all 0.3s ease;   /* Default transition */
}
```

**How to Customize Colors**: 
Simply change the hex values in the `:root` selector, and all elements using these variables will update automatically.

### Typography

```css
body {
    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    color: var(--text-dark);
    line-height: 1.6;
}
```

**Font System**:
- **Body Font**: Segoe UI with fallbacks
- **Line Height**: 1.6 for comfortable reading
- **Font Sizes**: Scale from 14px (small text) to 56px (hero title)

### Layout Classes

#### Container
```css
.container {
    max-width: 1200px;
    margin: 0 auto;
    padding: 0 20px;
}
```
**Purpose**: Constrains content width and centers it on the page.

#### Section Title
```css
.section-title {
    font-size: 42px;
    background: linear-gradient(...);
    -webkit-background-clip: text;
    -webkit-text-fill-color: transparent;
    animation: fadeInUp 0.8s ease;
}
```
**Purpose**: Styled heading with gradient text effect and entrance animation.

### Component Styles

#### Navigation Bar
- **Position**: Fixed at top (`position: fixed`)
- **Z-index**: 1000 (stays above other content)
- **Animation**: Slides down on page load
- **Hover Effect**: Underline animation on nav links

**Customization Tips**:
- Change `.navbar` background color to match your brand
- Modify `.nav-link::after` width/color for underline effect
- Adjust `.nav-container` height for larger/smaller navbar

#### Hero Section
- **Full Height**: `min-height: calc(100vh - 70px)` (accounts for navbar)
- **Flexbox Centering**: Centers content both vertically and horizontally
- **Background Animation**: Floating shapes using `@keyframes float`
- **Gradient Text**: Uses `-webkit-background-clip` for colorful headings

**Background Effects**:
- Animated circles using `::before` and `::after` pseudo-elements
- Radial gradients for circular shapes
- `animation: float` for gentle movement

#### Buttons & Links
```css
.cta-button {
    padding: 12px 40px;
    background: linear-gradient(...);
    border-radius: 50px;
    transition: var(--transition);
}

.cta-button:hover {
    transform: translateY(-3px);
    box-shadow: 0 10px 20px rgba(102, 126, 234, 0.3);
}
```

**Features**:
- Rounded pill-shape (`border-radius: 50px`)
- Gradient background
- Smooth hover effects
- Shadow elevation on hover

#### Cards (Skills, Projects, Stats)
```css
.skill-card {
    background: var(--white);
    padding: 30px;
    border-radius: 10px;
    box-shadow: var(--shadow-sm);
    transition: var(--transition);
    border-top: 3px solid var(--primary-color);
}

.skill-card:hover {
    transform: translateY(-10px);
    box-shadow: var(--shadow);
}
```

**Features**:
- White background with subtle shadow
- Colored top border
- Lift up animation on hover
- Enhanced shadow on hover

### Animations

#### Fade In Up
```css
@keyframes fadeInUp {
    from {
        opacity: 0;
        transform: translateY(30px);
    }
    to {
        opacity: 1;
        transform: translateY(0);
    }
}
```
**Usage**: Used for elements entering from bottom with fade effect.

#### Float
```css
@keyframes float {
    0%, 100% { transform: translateY(0); }
    50% { transform: translateY(-20px); }
}
```
**Usage**: Creates gentle up-and-down floating motion for decorative elements.

#### Grow Width
```css
@keyframes growWidth {
    from { width: 0 !important; }
}
```
**Usage**: Animates skill progress bars from 0 to target width.

**How to Add More Animations**:
1. Define `@keyframes` with from/to states
2. Apply animation using `animation` property
3. Customize duration, timing, and delay

### Grid Layouts

#### Skills Grid
```css
.skills-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 30px;
}
```
**Features**:
- Responsive auto-fit columns
- Minimum 300px cards
- Equal gaps between items
- Automatically adapts to screen size

#### Projects Grid
Same responsive approach with `repeat(auto-fit, minmax(320px, 1fr))`

**Advantage**: No need for media queries - grid automatically adjusts column count.

### Responsive Design

#### Tablet Breakpoint (768px)
```css
@media (max-width: 768px) {
    .hero-title { font-size: 36px; }
    .about-content { grid-template-columns: 1fr; }
    .contact-content { grid-template-columns: 1fr; }
}
```
**Changes**:
- Reduce font sizes by 20-30%
- Switch from 2-column to 1-column layout
- Adjust spacing and gaps

#### Mobile Breakpoint (480px)
```css
@media (max-width: 480px) {
    .hero-title { font-size: 28px; }
    .nav-menu { font-size: 14px; }
}
```
**Changes**:
- Further reduce font sizes
- Minimize padding/margins
- Stack elements vertically

**Mobile-First Approach**: Base styles are for mobile, then enhanced for larger screens.

### Form Styling
```css
.form-group input,
.form-group textarea {
    padding: 15px;
    border: 2px solid var(--bg-light);
    border-radius: 8px;
    transition: var(--transition);
}

.form-group input:focus,
.form-group textarea:focus {
    outline: none;
    border-color: var(--primary-color);
    box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
}
```

**Features**:
- Smooth focus states
- Color change on interaction
- Subtle shadow effect
- Proper spacing and padding

---

## 💬 JavaScript Documentation

### Overview
The `script.js` file handles all dynamic functionality including smooth scrolling, form validation, animations, and user interactions.

### Key Functions

#### 1. Smooth Scroll Navigation
```javascript
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const targetId = link.getAttribute('href');
        const targetSection = document.querySelector(targetId);
        
        if (targetSection) {
            const offsetTop = targetSection.offsetTop - 70;
            window.scrollTo({
                top: offsetTop,
                behavior: 'smooth'
            });
        }
    });
});
```

**Purpose**: Enables smooth scrolling to sections when nav links are clicked.

**How It Works**:
1. Prevents default link behavior with `e.preventDefault()`
2. Gets target section ID from href attribute
3. Calculates scroll position accounting for fixed navbar (70px offset)
4. Uses `window.scrollTo()` with `behavior: 'smooth'`

**Customization**: Change `70` to match your navbar height if different.

#### 2. Intersection Observer - Scroll Animations
```javascript
const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);
```

**Purpose**: Triggers animations when elements enter the viewport.

**How It Works**:
1. Creates IntersectionObserver with `threshold: 0.1` (trigger at 10% visible)
2. When element is intersecting (visible), applies animation styles
3. Removes observer from element to prevent re-triggering

**Advantage**: More performant than scroll event listeners.

#### 3. Form Validation
```javascript
function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}
```

**Purpose**: Validates email format using regex pattern.

**Pattern Breakdown**:
- `^[^\s@]+` - Starts with non-whitespace, non-@ characters
- `@` - Required @ symbol
- `[^\s@]+` - Non-whitespace, non-@ characters
- `\.` - Required dot
- `[^\s@]+$` - Ends with non-whitespace, non-@ characters

**Form Submission Handler**:
```javascript
contactForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    // Validate each field
    if (!nameInput.value.trim()) {
        showFormAlert('Please enter your name', 'error');
        return;
    }
    
    if (!validateEmail(emailInput.value)) {
        showFormAlert('Please enter a valid email', 'error');
        return;
    }
    
    // Show success and reset
    showFormAlert('Message sent successfully!', 'success');
    contactForm.reset();
});
```

#### 4. Toast Alert System
```javascript
function showFormAlert(message, type) {
    const alertDiv = document.createElement('div');
    alertDiv.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        padding: 16px 24px;
        background: ${type === 'success' ? '#48bb78' : '#f56565'};
        color: white;
        border-radius: 8px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        z-index: 2000;
        animation: slideInRight 0.4s ease;
        font-weight: 600;
    `;
    
    document.body.appendChild(alertDiv);
    
    // Auto-remove after 3 seconds
    setTimeout(() => {
        alertDiv.style.animation = 'slideOutRight 0.4s ease';
        setTimeout(() => alertDiv.remove(), 400);
    }, 3000);
}
```

**Purpose**: Shows temporary notifications to user.

**Features**:
- Dynamic creation of alert elements
- Color based on success/error type
- Auto-removal after 3 seconds
- Slide animation

**How to Use**:
```javascript
showFormAlert('Your message here', 'success'); // Green alert
showFormAlert('Error message', 'error');        // Red alert
```

#### 5. Skill Progress Animation
```javascript
const skillObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            const skillProgress = entry.target.querySelector('.skill-progress');
            const targetWidth = skillProgress.style.width;
            
            skillProgress.style.width = '0';
            setTimeout(() => {
                skillProgress.style.width = targetWidth;
            }, 100);
            
            skillObserver.unobserve(entry.target);
        }
    });
});
```

**Purpose**: Animates progress bars when skill cards come into view.

**How It Works**:
1. Waits for skill card to become visible
2. Resets width to 0
3. Animates back to target width with CSS transition
4. Removes observer to prevent re-animation

#### 6. Active Navigation Indicator
```javascript
document.addEventListener('scroll', () => {
    const sections = document.querySelectorAll('section[id]');
    let currentSection = '';
    
    sections.forEach(section => {
        const sectionTop = section.offsetTop - 100;
        if (window.scrollY >= sectionTop) {
            currentSection = section.getAttribute('id');
        }
    });
    
    navLinks.forEach(link => {
        link.style.color = '';
        if (link.getAttribute('href').slice(1) === currentSection) {
            link.style.color = 'var(--primary-color)';
        }
    });
});
```

**Purpose**: Highlights current section in navigation as user scrolls.

**How It Works**:
1. Finds all sections with IDs
2. Calculates each section's top position
3. Compares current scroll position to section positions
4. Colors the matching nav link with primary color

#### 7. Parallax Scroll Effect
```javascript
document.addEventListener('scroll', () => {
    const heroBackground = document.querySelector('.hero-background');
    if (heroBackground && window.scrollY < window.innerHeight) {
        heroBackground.style.transform = `translateY(${window.scrollY * 0.5}px)`;
    }
});
```

**Purpose**: Moves background elements at different speed than scroll.

**How It Works**:
- Multiplies scroll amount by 0.5 (50% speed)
- Creates depth effect with layered movement
- Only applies within hero section

**Customization**: Change `0.5` to different values:
- `0.3` = Slower parallax
- `0.8` = Faster parallax

#### 8. Keyboard Navigation
```javascript
document.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown') {
        window.scrollBy({
            top: window.innerHeight / 2,
            behavior: 'smooth'
        });
    } else if (e.key === 'ArrowUp') {
        window.scrollBy({
            top: -window.innerHeight / 2,
            behavior: 'smooth'
        });
    }
});
```

**Purpose**: Allows users to scroll with arrow keys.

**Features**:
- Arrow Down: Scroll down half viewport
- Arrow Up: Scroll up half viewport
- Smooth scrolling animation

#### 9. Debounce Function
```javascript
function debounce(func, delay) {
    let timeoutId;
    return function(...args) {
        clearTimeout(timeoutId);
        timeoutId = setTimeout(() => func.apply(this, args), delay);
    };
}

const debouncedScroll = debounce(() => {
    // Optimized handlers here
}, 100);

document.addEventListener('scroll', debouncedScroll);
```

**Purpose**: Prevents excessive function calls during rapid events.

**How It Works**:
- Delays function execution by specified milliseconds
- Cancels previous timeout if event fires again
- Reduces CPU usage on scroll/resize events

**Use Case**: Expensive operations that don't need to run on every scroll event.

### Event Listeners

**DOMContentLoaded**: Initializes all interactive features after DOM loads
```javascript
document.addEventListener('DOMContentLoaded', () => {
    // Navigation setup
    // Form setup
    // Observer setup
    // Animation setup
});
```

**scroll**: Handles scroll-dependent features
```javascript
document.addEventListener('scroll', () => {
    // Active nav indicator
    // Parallax effect
    // Progress tracking
});
```

**Submit**: Handles form submission and validation
```javascript
contactForm.addEventListener('submit', (e) => {
    e.preventDefault();
    // Validation logic
    // Submission handling
});
```

### Adding Custom Features

#### Add Countdown Timer
```javascript
function startCountdown(elementId, endDate) {
    setInterval(() => {
        const now = new Date().getTime();
        const distance = endDate - now;
        const days = Math.floor(distance / (1000 * 60 * 60 * 24));
        document.getElementById(elementId).textContent = `${days} days left`;
    }, 1000);
}
```

#### Add Smooth Scroll to Top Button
```javascript
const scrollToTopBtn = document.getElementById('scrollToTop');
window.addEventListener('scroll', () => {
    scrollToTopBtn.style.display = window.scrollY > 300 ? 'block' : 'none';
});
scrollToTopBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});
```

#### Add Analytics Tracking
```javascript
// Track section views
sections.forEach(section => {
    observer.observe(section);
    // Send analytics event when section is viewed
});
```

---

## 🚀 Getting Started

### 1. Customize Content
- Edit `index.html` to add your name, projects, skills, and contact info
- Replace placeholder text with your actual information

### 2. Customize Colors
Edit `:root` variables in `styles.css`:
```css
:root {
    --primary-color: #667eea;      /* Change this */
    --secondary-color: #764ba2;    /* Change this */
    --accent-color: #f5576c;       /* Change this */
}
```

### 3. Add Your Projects
Copy a project card and customize:
```html
<div class="project-card">
    <div class="project-image" style="background: linear-gradient(135deg, #YOUR_COLOR_1 0%, #YOUR_COLOR_2 100%)"></div>
    <h3>Your Project Title</h3>
    <p>Your project description...</p>
    <div class="project-tags">
        <span class="tag">Technology1</span>
        <span class="tag">Technology2</span>
    </div>
    <a href="your-project-url" class="project-link">View Project →</a>
</div>
```

### 4. Update Skills
Add or modify skill cards with your proficiencies:
```html
<div class="skill-card">
    <h3>Your Skill</h3>
    <div class="skill-bar">
        <div class="skill-progress" style="width: 85%"></div>
    </div>
    <p>85%</p>
</div>
```

---

## 🌐 Deployment

### GitHub Pages
1. Create a GitHub repository named `username.github.io`
2. Push your portfolio files to the repository
3. Your site will be live at `https://username.github.io`

### Netlify
1. Sign up at [netlify.com](https://netlify.com)
2. Drag and drop your project folder
3. Site deployed instantly
4. Add custom domain in settings

### Vercel
1. Sign up at [vercel.com](https://vercel.com)
2. Import your GitHub repository
3. Auto-deploys on each push
4. Excellent performance

---

## 🎓 Learning Resources

- **HTML**: [MDN Web Docs - HTML](https://developer.mozilla.org/en-US/docs/Web/HTML)
- **CSS**: [CSS-Tricks](https://css-tricks.com/) | [MDN CSS](https://developer.mozilla.org/en-US/docs/Web/CSS)
- **JavaScript**: [JavaScript.info](https://javascript.info/) | [MDN JS](https://developer.mozilla.org/en-US/docs/Web/JavaScript)
- **Web Design**: [Dribbble](https://dribbble.com) | [Behance](https://behance.net)

---

## 🛠️ Browser Support

- Chrome 90+
- Firefox 88+
- Safari 14+
- Edge 90+

---

## 📝 License

This portfolio template is free to use and modify for personal projects.

---

## 💡 Tips for Best Results

1. **Keep It Simple**: Clean design is professional design
2. **Mobile First**: Test on mobile devices first
3. **Fast Loading**: Optimize images before uploading
4. **SEO Friendly**: Use descriptive titles and meta tags
5. **Regular Updates**: Keep project list and skills current
6. **Professional Photos**: Use quality headshots and project images
7. **Consistent Branding**: Use 2-3 main colors throughout

---

## 🤝 Need Help?

- Check the inline code comments
- Review the function documentation
- Test in browser DevTools (F12)
- Refer to official documentation links above

---

**Made with ❤️ - Your Professional Portfolio Awaits!**
