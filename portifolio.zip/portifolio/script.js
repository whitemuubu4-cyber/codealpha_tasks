/**
 * Portfolio Website - JavaScript Functionality
 * Handles smooth scrolling, form validation, animations, and interactivity
 */

// ============================================
// SMOOTH SCROLL BEHAVIOR
// ============================================

/**
 * Handles smooth scrolling to sections when navigation links are clicked
 * Uses IntersectionObserver to animate elements as they come into view
 */
document.addEventListener('DOMContentLoaded', () => {
  // Smooth scroll for navigation links
  const navLinks = document.querySelectorAll('.nav-link');

  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const targetId = link.getAttribute('href');
      const targetSection = document.querySelector(targetId);

      if (targetSection) {
        // Smooth scroll with offset for fixed navbar
        const offsetTop = targetSection.offsetTop - 70;
        window.scrollTo({
          top: offsetTop,
          behavior: 'smooth'
        });
      }
    });
  });
});

// ============================================
// INTERSECTION OBSERVER - ANIMATIONS ON SCROLL
// ============================================

/**
 * Creates an IntersectionObserver to trigger animations
 * when elements enter the viewport during scrolling
 */
const observerOptions = {
  threshold: 0.1,
  rootMargin: '0px 0px -100px 0px'
};

const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      // Add animation class when element comes into view
      entry.target.style.opacity = '1';
      entry.target.style.transform = 'translateY(0)';
      observer.unobserve(entry.target);
    }
  });
}, observerOptions);

// Observe all sections and cards for animation
document.addEventListener('DOMContentLoaded', () => {
  const elementsToAnimate = document.querySelectorAll(
    '.skill-card, .project-card, .stat, .about-text'
  );

  elementsToAnimate.forEach(element => {
    element.style.opacity = '0';
    element.style.transform = 'translateY(20px)';
    element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
    observer.observe(element);
  });
});

// ============================================
// FORM VALIDATION AND SUBMISSION
// ============================================

/**
 * Validates and handles contact form submission
 * Prevents default submission and provides user feedback
 */
document.addEventListener('DOMContentLoaded', () => {
  const contactForm = document.querySelector('.contact-form');

  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();

      // Get form inputs
      const nameInput = contactForm.querySelector('input[type="text"]');
      const emailInput = contactForm.querySelector('input[type="email"]');
      const messageInput = contactForm.querySelector('textarea');

      // Validate inputs
      if (!nameInput.value.trim()) {
        showFormAlert('Please enter your name', 'error');
        return;
      }

      if (!validateEmail(emailInput.value)) {
        showFormAlert('Please enter a valid email', 'error');
        return;
      }

      if (!messageInput.value.trim()) {
        showFormAlert('Please enter your message', 'error');
        return;
      }

      // Show success message
      showFormAlert('Message sent successfully! I will get back to you soon.', 'success');

      // Reset form
      contactForm.reset();

      // Reset button style
      const submitBtn = contactForm.querySelector('.submit-btn');
      submitBtn.style.opacity = '1';
      submitBtn.style.pointerEvents = 'auto';
    });
  }
});

/**
 * Validates email format using regex
 * @param {string} email - Email to validate
 * @returns {boolean} - True if email is valid
 */
function validateEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

/**
 * Shows alert message to user
 * @param {string} message - Message to display
 * @param {string} type - Alert type ('success' or 'error')
 */
function showFormAlert(message, type) {
  const alertDiv = document.createElement('div');
  alertDiv.style.cssText = `
        position: fixed;
        top: 100px;
        right: 20px;
        padding: 16px 24px;
        background: ${type === 'success' ? '#48bb78' : '#f56565'};
        color: white;
        border-radius: 8px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
        z-index: 2000;
        animation: slideInRight 0.4s ease;
        font-weight: 600;
    `;

  alertDiv.textContent = message;
  document.body.appendChild(alertDiv);

  // Remove alert after 3 seconds
  setTimeout(() => {
    alertDiv.style.animation = 'slideOutRight 0.4s ease';
    setTimeout(() => alertDiv.remove(), 400);
  }, 3000);
}

// ============================================
// SKILL PROGRESS ANIMATION
// ============================================

/**
 * Animates skill progress bars when they come into view
 * Fills the progress bars with a smooth animation
 */
document.addEventListener('DOMContentLoaded', () => {
  const skillCards = document.querySelectorAll('.skill-card');
  const skillObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const skillProgress = entry.target.querySelector('.skill-progress');
        const targetWidth = skillProgress.style.width;

        // Reset width and trigger animation
        skillProgress.style.width = '0';
        setTimeout(() => {
          skillProgress.style.width = targetWidth;
        }, 100);

        skillObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.5 });

  skillCards.forEach(card => skillObserver.observe(card));
});

// ============================================
// HOVER EFFECTS FOR PROJECT CARDS
// ============================================

/**
 * Adds interactive hover effects to project cards
 * Scales and adds shadow on hover
 */
document.addEventListener('DOMContentLoaded', () => {
  const projectCards = document.querySelectorAll('.project-card');

  projectCards.forEach(card => {
    card.addEventListener('mouseenter', () => {
      card.style.boxShadow = '0 20px 40px rgba(0, 0, 0, 0.15)';
    });

    card.addEventListener('mouseleave', () => {
      card.style.boxShadow = '0 4px 6px rgba(0, 0, 0, 0.07)';
    });
  });
});

// ============================================
// NAVBAR ACTIVE STATE INDICATOR
// ============================================

/**
 * Updates active nav link based on scroll position
 * Highlights the section currently in view
 */
document.addEventListener('scroll', () => {
  const sections = document.querySelectorAll('section[id]');
  const navLinks = document.querySelectorAll('.nav-link');

  let currentSection = '';

  sections.forEach(section => {
    const sectionTop = section.offsetTop - 100;
    if (window.scrollY >= sectionTop) {
      currentSection = section.getAttribute('id');
    }
  });

  navLinks.forEach(link => {
    link.style.color = '';
    if (link.getAttribute('href').slice(1) === currentSection) {
      link.style.color = 'var(--primary-color)';
    }
  });
});

// ============================================
// SCROLL PROGRESS INDICATOR
// ============================================

/**
 * Shows scroll progress as user scrolls down the page
 * Optional: Can be added to navbar for better UX
 */
document.addEventListener('scroll', () => {
  const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
  const scrolled = (window.scrollY / scrollHeight) * 100;

  // You can use this for a progress bar in the navbar
  // Example: Update a progress bar element if it exists
  const progressBar = document.getElementById('scroll-progress');
  if (progressBar) {
    progressBar.style.width = scrolled + '%';
  }
});

// ============================================
// PARALLAX SCROLL EFFECT
// ============================================

/**
 * Creates parallax effect on hero background
 * Moves background elements at different speeds than scroll
 */
document.addEventListener('scroll', () => {
  const heroBackground = document.querySelector('.hero-background');
  if (heroBackground && window.scrollY < window.innerHeight) {
    heroBackground.style.transform = `translateY(${window.scrollY * 0.5}px)`;
  }
});

// ============================================
// ANIMATION KEYFRAMES (for CSS)
// ============================================

// Add animation styles dynamically
const style = document.createElement('style');
style.textContent = `
    @keyframes slideInRight {
        from {
            opacity: 0;
            transform: translateX(100px);
        }
        to {
            opacity: 1;
            transform: translateX(0);
        }
    }
    
    @keyframes slideOutRight {
        from {
            opacity: 1;
            transform: translateX(0);
        }
        to {
            opacity: 0;
            transform: translateX(100px);
        }
    }
`;
document.head.appendChild(style);

// ============================================
// PRELOADER/LOADING ANIMATION
// ============================================

/**
 * Optional: Hide preloader when page is fully loaded
 * Useful for slower connections
 */
window.addEventListener('load', () => {
  const preloader = document.getElementById('preloader');
  if (preloader) {
    preloader.style.display = 'none';
  }
});

// ============================================
// KEYBOARD NAVIGATION
// ============================================

/**
 * Enables keyboard navigation with arrow keys
 * Allows users to navigate between sections using keyboard
 */
document.addEventListener('keydown', (e) => {
  if (e.key === 'ArrowDown') {
    const currentScroll = window.scrollY;
    window.scrollBy({
      top: window.innerHeight / 2,
      behavior: 'smooth'
    });
  } else if (e.key === 'ArrowUp') {
    window.scrollBy({
      top: -window.innerHeight / 2,
      behavior: 'smooth'
    });
  }
});

// ============================================
// COPY TO CLIPBOARD FUNCTIONALITY
// ============================================

/**
 * Copies email or social links to clipboard
 * Provides user feedback on successful copy
 */
function copyToClipboard(text) {
  navigator.clipboard.writeText(text).then(() => {
    showFormAlert('Copied to clipboard!', 'success');
  }).catch(err => {
    console.error('Failed to copy:', err);
  });
}

// ============================================
// PERFORMANCE OPTIMIZATION
// ============================================

/**
 * Debounce function to optimize scroll events
 * Prevents excessive function calls during scroll
 */
function debounce(func, delay) {
  let timeoutId;
  return function (...args) {
    clearTimeout(timeoutId);
    timeoutId = setTimeout(() => func.apply(this, args), delay);
  };
}

// Use debounce for scroll-heavy operations
const debouncedScroll = debounce(() => {
  // Optimized scroll handlers here
}, 100);

document.addEventListener('scroll', debouncedScroll);

// ============================================
// CONSOLE LOG FOR DEBUGGING
// ============================================

console.log('Portfolio website loaded successfully!');
console.log('Features: Smooth scroll, animations, form validation, parallax effects');
