// Advanced Scientific Calculator Class
class ScientificCalculator {
  constructor(previousOperandElement, currentOperandElement, memoryIndicator) {
    this.previousOperandElement = previousOperandElement;
    this.currentOperandElement = currentOperandElement;
    this.memoryIndicator = memoryIndicator;
    this.memory = 0;
    this.history = [];
    this.statsData = [];
    this.clear();
  }

  // Basic operations
  clear() {
    this.currentOperand = '';
    this.previousOperand = '';
    this.operation = undefined;
    this.updateDisplay();
  }

  delete() {
    this.currentOperand = this.currentOperand.toString().slice(0, -1);
    this.updateDisplay();
  }

  appendNumber(number) {
    if (number === '.' && this.currentOperand.includes('.')) return;
    this.currentOperand = this.currentOperand.toString() + number.toString();
    this.updateDisplay();
  }

  chooseOperation(operation) {
    if (this.currentOperand === '') return;
    if (this.previousOperand !== '') {
      this.compute();
    }
    this.operation = operation;
    this.previousOperand = this.currentOperand;
    this.currentOperand = '';
    this.updateDisplay();
  }

  compute() {
    let computation;
    const prev = parseFloat(this.previousOperand);
    const current = parseFloat(this.currentOperand);

    if (isNaN(prev) || isNaN(current)) return;

    switch (this.operation) {
      case '+':
        computation = prev + current;
        break;
      case '-':
        computation = prev - current;
        break;
      case '×':
        computation = prev * current;
        break;
      case '÷':
        if (current === 0) {
          alert('Cannot divide by zero!');
          this.clear();
          return;
        }
        computation = prev / current;
        break;
      case '%':
        computation = prev % current;
        break;
      default:
        return;
    }

    this.addToHistory(`${prev} ${this.operation} ${current} = ${computation}`);
    this.currentOperand = computation;
    this.operation = undefined;
    this.previousOperand = '';
    this.updateDisplay();
  }

  // Scientific functions
  sin() {
    const value = parseFloat(this.currentOperand);
    if (isNaN(value)) return;
    this.currentOperand = Math.sin(value * Math.PI / 180);
    this.updateDisplay();
  }

  cos() {
    const value = parseFloat(this.currentOperand);
    if (isNaN(value)) return;
    this.currentOperand = Math.cos(value * Math.PI / 180);
    this.updateDisplay();
  }

  tan() {
    const value = parseFloat(this.currentOperand);
    if (isNaN(value)) return;
    this.currentOperand = Math.tan(value * Math.PI / 180);
    this.updateDisplay();
  }

  sqrt() {
    const value = parseFloat(this.currentOperand);
    if (isNaN(value) || value < 0) return alert('Cannot calculate sqrt of negative');
    this.currentOperand = Math.sqrt(value);
    this.updateDisplay();
  }

  cbrt() {
    const value = parseFloat(this.currentOperand);
    if (isNaN(value)) return;
    this.currentOperand = Math.cbrt(value);
    this.updateDisplay();
  }

  logarithm() {
    const value = parseFloat(this.currentOperand);
    if (isNaN(value) || value <= 0) return alert('Logarithm undefined for non-positive numbers');
    this.currentOperand = Math.log10(value);
    this.updateDisplay();
  }

  naturalLog() {
    const value = parseFloat(this.currentOperand);
    if (isNaN(value) || value <= 0) return alert('Natural log undefined for non-positive numbers');
    this.currentOperand = Math.log(value);
    this.updateDisplay();
  }

  power(exponent) {
    const value = parseFloat(this.currentOperand);
    if (isNaN(value) || isNaN(exponent)) return;
    this.currentOperand = Math.pow(value, exponent);
    this.updateDisplay();
  }

  factorial() {
    const n = parseFloat(this.currentOperand);
    if (isNaN(n) || n < 0) return alert('Factorial undefined for negative numbers');
    if (n > 170) return alert('Factorial too large');

    let result = 1;
    for (let i = 2; i <= n; i++) result *= i;
    this.currentOperand = result;
    this.updateDisplay();
  }

  reciprocal() {
    const value = parseFloat(this.currentOperand);
    if (value === 0) return alert('Cannot divide by zero');
    this.currentOperand = 1 / value;
    this.updateDisplay();
  }

  absoluteValue() {
    const value = parseFloat(this.currentOperand);
    if (isNaN(value)) return;
    this.currentOperand = Math.abs(value);
    this.updateDisplay();
  }

  appendPi() {
    this.currentOperand = Math.PI;
    this.updateDisplay();
  }

  appendE() {
    this.currentOperand = Math.E;
    this.updateDisplay();
  }

  randomNumber() {
    this.currentOperand = Math.random();
    this.updateDisplay();
  }

  // Memory functions
  memoryAdd() {
    const value = parseFloat(this.currentOperand);
    if (!isNaN(value)) {
      this.memory += value;
      this.updateMemoryIndicator();
    }
  }

  memorySubtract() {
    const value = parseFloat(this.currentOperand);
    if (!isNaN(value)) {
      this.memory -= value;
      this.updateMemoryIndicator();
    }
  }

  memoryRecall() {
    this.currentOperand = this.memory;
    this.updateDisplay();
  }

  memoryClear() {
    this.memory = 0;
    this.updateMemoryIndicator();
  }

  updateMemoryIndicator() {
    if (this.memory !== 0) {
      this.memoryIndicator.textContent = `M: ${this.formatNumber(this.memory)}`;
    } else {
      this.memoryIndicator.textContent = '';
    }
  }

  // Statistics functions
  addDataPoint() {
    const value = parseFloat(this.currentOperand);
    if (!isNaN(value)) {
      this.statsData.push(value);
      this.currentOperand = '';
      this.updateDisplay();
    }
  }

  calculateMean() {
    if (this.statsData.length === 0) return alert('No data points');
    const sum = this.statsData.reduce((a, b) => a + b, 0);
    const mean = sum / this.statsData.length;
    this.currentOperand = mean;
    this.updateDisplay();
  }

  calculateSum() {
    if (this.statsData.length === 0) return alert('No data points');
    const sum = this.statsData.reduce((a, b) => a + b, 0);
    this.currentOperand = sum;
    this.updateDisplay();
  }

  calculateStdDev() {
    if (this.statsData.length === 0) return alert('No data points');
    const mean = this.statsData.reduce((a, b) => a + b, 0) / this.statsData.length;
    const variance = this.statsData.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / this.statsData.length;
    const stdDev = Math.sqrt(variance);
    this.currentOperand = stdDev;
    this.updateDisplay();
  }

  calculateVariance() {
    if (this.statsData.length === 0) return alert('No data points');
    const mean = this.statsData.reduce((a, b) => a + b, 0) / this.statsData.length;
    const variance = this.statsData.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / this.statsData.length;
    this.currentOperand = variance;
    this.updateDisplay();
  }

  // History management
  addToHistory(calculation) {
    this.history.push(calculation);
  }

  getHistory() {
    return this.history;
  }

  clearHistory() {
    this.history = [];
  }

  // Display formatting
  updateDisplay() {
    this.currentOperandElement.innerText = this.formatNumber(this.currentOperand);

    if (this.operation != null) {
      this.previousOperandElement.innerText =
        `${this.formatNumber(this.previousOperand)} ${this.operation}`;
    } else {
      this.previousOperandElement.innerText = '';
    }
  }

  formatNumber(number) {
    const stringNumber = number.toString();
    const integerDigits = parseFloat(stringNumber.split('.')[0]);
    const decimalDigits = stringNumber.split('.')[1];

    let integerDisplay;
    if (isNaN(integerDigits)) {
      integerDisplay = '';
    } else {
      integerDisplay = integerDigits.toLocaleString('en', {
        maximumFractionDigits: 0
      });
    }

    if (decimalDigits != null) {
      return `${integerDisplay}.${decimalDigits}`;
    } else {
      return integerDisplay;
    }
  }
}

// Initialize calculator
const previousOperandElement = document.getElementById('previousOperand');
const currentOperandElement = document.getElementById('display');
const memoryIndicator = document.getElementById('memoryIndicator');
const calculator = new ScientificCalculator(previousOperandElement, currentOperandElement, memoryIndicator);

// Mode switching
const modeBtns = document.querySelectorAll('.mode-btn');
const basicGrid = document.getElementById('basicGrid');
const scientificGrid = document.getElementById('scientificGrid');
const statsGrid = document.getElementById('statsGrid');

modeBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    modeBtns.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');

    const mode = btn.dataset.mode;
    basicGrid.classList.toggle('hidden', mode !== 'basic');
    scientificGrid.classList.toggle('hidden', mode !== 'scientific');
    statsGrid.classList.toggle('hidden', mode !== 'stats');
  });
});

// Basic mode buttons
const numberButtons = document.querySelectorAll('[data-number]');
const operatorButtons = document.querySelectorAll('[data-operator]');
const functionButtons = document.querySelectorAll('[data-action]');

numberButtons.forEach(button => {
  button.addEventListener('click', () => {
    calculator.appendNumber(button.dataset.number);
  });
});

operatorButtons.forEach(button => {
  button.addEventListener('click', () => {
    calculator.chooseOperation(button.dataset.operator);
  });
});

functionButtons.forEach(button => {
  button.addEventListener('click', () => {
    const action = button.dataset.action;
    if (action === 'clear') {
      calculator.clear();
    } else if (action === 'delete') {
      calculator.delete();
    } else if (action === 'calculate') {
      calculator.compute();
    } else if (action === 'clear-history') {
      calculator.clearHistory();
      updateHistoryDisplay();
    } else if (action === 'm-plus') {
      calculator.memoryAdd();
    } else if (action === 'm-minus') {
      calculator.memorySubtract();
    } else if (action === 'm-recall') {
      calculator.memoryRecall();
    } else if (action === 'm-clear') {
      calculator.memoryClear();
    }
  });
});

// Scientific function buttons
const scientificButtons = document.querySelectorAll('[data-func]');
scientificButtons.forEach(button => {
  button.addEventListener('click', () => {
    const func = button.dataset.func;
    switch (func) {
      case 'sin':
        calculator.sin();
        break;
      case 'cos':
        calculator.cos();
        break;
      case 'tan':
        calculator.tan();
        break;
      case 'sqrt':
        calculator.sqrt();
        break;
      case 'cbrt':
        calculator.cbrt();
        break;
      case 'log':
        calculator.logarithm();
        break;
      case 'ln':
        calculator.naturalLog();
        break;
      case 'factorial':
        calculator.factorial();
        break;
      case 'reciprocal':
        calculator.reciprocal();
        break;
      case 'abs':
        calculator.absoluteValue();
        break;
      case 'pi':
        calculator.appendPi();
        break;
      case 'e':
        calculator.appendE();
        break;
      case 'rand':
        calculator.randomNumber();
        break;
      case 'pow':
        const exponent = prompt('Enter exponent:');
        if (exponent !== null) calculator.power(parseFloat(exponent));
        break;
      case 'data-enter':
        calculator.addDataPoint();
        break;
      case 'mean':
        calculator.calculateMean();
        break;
      case 'sum':
        calculator.calculateSum();
        break;
      case 'stdev':
        calculator.calculateStdDev();
        break;
      case 'variance':
        calculator.calculateVariance();
        break;
    }
  });
});

// Keyboard support
document.addEventListener('keydown', (e) => {
  if (e.key >= '0' && e.key <= '9') {
    calculator.appendNumber(e.key);
    e.preventDefault();
  } else if (e.key === '.') {
    calculator.appendNumber(e.key);
    e.preventDefault();
  }

  switch (e.key) {
    case '+':
    case '-':
    case '*':
    case '/':
      calculator.chooseOperation(e.key === '*' ? '×' : e.key === '/' ? '÷' : e.key);
      e.preventDefault();
      break;
    case 'Enter':
    case '=':
      calculator.compute();
      e.preventDefault();
      break;
    case 'Backspace':
      calculator.delete();
      e.preventDefault();
      break;
    case 'Escape':
      calculator.clear();
      e.preventDefault();
      break;
  }
});

// History display update
function updateHistoryDisplay() {
  const historyList = document.getElementById('historyList');
  historyList.innerHTML = '';
  calculator.getHistory().forEach(item => {
    const div = document.createElement('div');
    div.className = 'history-item';
    div.textContent = item;
    historyList.appendChild(div);
  });
}
