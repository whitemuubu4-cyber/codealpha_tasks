# Calculator App - Complete Guide

A fully functional calculator web application built with HTML, CSS, and JavaScript. Features a modern UI with smooth animations, keyboard support, and comprehensive error handling.

---

## 📁 Project Files

1. **calculator.html** - HTML structure and layout
2. **calculator.css** - Styling, responsive design, and animations
3. **calculator.js** - Calculator logic and event handling
4. **README.md** - This documentation file
5. **.gitignore** - Git configuration file

---

## 🎯 Features

✅ **All Arithmetic Operations**: Addition, Subtraction, Multiplication, Division  
✅ **Keyboard Support**: Full keyboard input for numbers and operators  
✅ **Clear & Delete Functions**: Clear all (AC) and delete last digit (DEL)  
✅ **Decimal Support**: Handle floating-point calculations  
✅ **Error Handling**: Prevents division by zero  
✅ **Responsive Design**: Works on desktop and mobile devices  
✅ **Smooth Animations**: Visual feedback on button clicks and interactions  
✅ **Number Formatting**: Displays numbers with comma separators for readability  

---

## 📋 HTML Structure

### File: `calculator.html`

#### Main Sections:

1. **Head Section**
   - Meta tags for character encoding and viewport (responsive design)
   - Link to external CSS stylesheet

2. **Body Structure**

   ```html
   <div class="container">
       <div class="calculator">
           <!-- Display Area -->
           <div class="display-container">
               <div class="previous-operand" id="previousOperand"></div>
               <div class="display" id="display">0</div>
           </div>
           
           <!-- Buttons Grid -->
           <div class="buttons-grid">
               <!-- Calculator buttons -->
           </div>
       </div>
   </div>
   ```

#### Key HTML Elements:

| Element | Purpose |
|---------|---------|
| `display-container` | Contains previous operand and current display |
| `display` | Shows current number being entered |
| `previousOperand` | Shows previous number and operator |
| `buttons-grid` | CSS Grid container for all buttons |
| `number-btn` | Buttons for digits 0-9 |
| `operator-btn` | Buttons for +, -, ×, ÷, . |
| `function-btn` | AC (clear) and DEL (delete) buttons |
| `equals-btn` | Button to compute result |

#### Data Attributes Used:

- `data-number`: Stores the number value (0-9, .)
- `data-operator`: Stores the operator symbol (+, -, ×, ÷, .)
- `data-action`: Stores the action type (clear, delete, calculate)

---

## 🎨 CSS Styling

### File: `calculator.css`

#### Key CSS Features:

1. **Layout & Structure**
   - **Flexbox**: Used for centering the calculator on the page
   - **CSS Grid**: Used for button layout (4 columns)
   - **Responsive Design**: Media queries for mobile devices

2. **Color Scheme**
   ```css
   Primary Gradient: linear-gradient(135deg, #667eea 0%, #764ba2 100%)
   Secondary Gradient: linear-gradient(135deg, #00d2fc 0%, #3a7bd5 100%)
   Accent Color: #ff6b6b (for clear/delete buttons)
   ```

3. **Button Styling**

   ```css
   .btn {
       padding: 20px;
       font-size: 20px;
       border-radius: 10px;
       cursor: pointer;
       transition: all 0.3s ease;
       box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
   }
   ```

   **Button Types:**
   - `.number-btn`: White background, light gray on hover
   - `.operator-btn`: Purple gradient, darker on hover
   - `.function-btn`: Red color for AC/DEL buttons
   - `.equals-btn`: Blue gradient, spans 2 columns
   - `.zero-btn`: Spans 2 columns for better spacing

4. **Animations**

   ```css
   @keyframes slideIn {
       from {
           opacity: 0;
           transform: translateY(30px);
       }
       to {
           opacity: 1;
           transform: translateY(0);
       }
   }
   ```

   - Applied to calculator on page load
   - Smooth transitions on button interactions (translateY on hover)
   - Press effect: button moves down slightly on click

5. **Display Area**
   - Gradient background matching the theme
   - `previous-operand`: Shows previous number and operator
   - `display`: Shows current input with large 48px font
   - Right-aligned for natural number reading

6. **Responsive Breakpoints**

   **Mobile (max-width: 480px):**
   - Reduced font sizes
   - Smaller padding and gaps
   - Maintains full functionality on small screens

7. **Accessibility**
   - Focus indicators on buttons
   - Respects `prefers-reduced-motion` for users who prefer minimal animations
   - Clear color contrast for readability

---

## 💻 JavaScript Logic

### File: `calculator.js`

#### 1. **Calculator Class**

The core of the application is the `Calculator` class that manages all calculations:

```javascript
class Calculator {
    constructor(previousOperandElement, currentOperandElement)
    clear()              // Reset calculator
    delete()             // Remove last digit
    appendNumber(number) // Add digit to display
    chooseOperation()    // Select an operator
    compute()            // Perform calculation
    formatNumber()       // Format display with commas
    updateDisplay()      // Update both display areas
}
```

#### 2. **Class Methods Explained**

**clear()**
```javascript
clear() {
    this.currentOperand = '';
    this.previousOperand = '';
    this.operation = undefined;
    this.updateDisplay();
}
```
- Resets all values to empty strings
- Resets operation to undefined
- Updates the display to show "0"

**appendNumber(number)**
```javascript
appendNumber(number) {
    if (number === '.' && this.currentOperand.includes('.')) return;
    this.currentOperand = this.currentOperand.toString() + number.toString();
    this.updateDisplay();
}
```
- Prevents multiple decimal points in one number
- Concatenates number to current operand
- Updates display in real-time

**chooseOperation(operation)**
```javascript
chooseOperation(operation) {
    if (this.currentOperand === '') return;
    if (this.previousOperand !== '') {
        this.compute();  // Calculate previous operation first
    }
    this.operation = operation;
    this.previousOperand = this.currentOperand;
    this.currentOperand = '';
    this.updateDisplay();
}
```
- Allows chain calculations (e.g., 5 + 3 + 2 = 10)
- Moves current number to previous operand
- Clears current operand for next number
- Sets the operation symbol

**compute()**
```javascript
compute() {
    let computation;
    const prev = parseFloat(this.previousOperand);
    const current = parseFloat(this.currentOperand);
    
    if (isNaN(prev) || isNaN(current)) return;
    
    switch (this.operation) {
        case '+':
            computation = prev + current;
            break;
        case '-':
            computation = prev - current;
            break;
        case '×':
            computation = prev * current;
            break;
        case '÷':
            if (current === 0) {
                alert('Cannot divide by zero!');
                this.clear();
                return;
            }
            computation = prev / current;
            break;
    }
    
    this.currentOperand = computation;
    this.operation = undefined;
    this.previousOperand = '';
}
```
- Converts string operands to numbers using `parseFloat()`
- Uses switch statement for operation selection
- Includes division by zero protection
- Stores result in current operand

**formatNumber(number)**
```javascript
formatNumber(number) {
    const stringNumber = number.toString();
    const integerDigits = parseFloat(stringNumber.split('.')[0]);
    const decimalDigits = stringNumber.split('.')[1];
    
    let integerDisplay;
    if (isNaN(integerDigits)) {
        integerDisplay = '';
    } else {
        integerDisplay = integerDigits.toLocaleString('en', { 
            maximumFractionDigits: 0 
        });
    }
    
    if (decimalDigits != null) {
        return `${integerDisplay}.${decimalDigits}`;
    } else {
        return integerDisplay;
    }
}
```
- Splits number into integer and decimal parts
- Uses `toLocaleString()` to add comma separators
- Maintains decimal precision
- Example: `1000.5` displays as `1,000.5`

#### 3. **Event Listeners**

**Number Button Listeners**
```javascript
numberButtons.forEach(button => {
    button.addEventListener('click', () => {
        calculator.appendNumber(button.dataset.number);
    });
});
```
- Iterates through all number buttons
- Attaches click event to each
- Passes the button's `data-number` value to `appendNumber()`

**Operator Button Listeners**
```javascript
operatorButtons.forEach(button => {
    button.addEventListener('click', () => {
        calculator.chooseOperation(button.dataset.operator);
    });
});
```
- Similar to number buttons
- Passes operator from `data-operator` attribute

**Function Button Listeners**
```javascript
functionButtons.forEach(button => {
    button.addEventListener('click', () => {
        if (button.dataset.action === 'clear') {
            calculator.clear();
        } else if (button.dataset.action === 'delete') {
            calculator.delete();
        } else if (button.dataset.action === 'calculate') {
            calculator.compute();
        }
    });
});
```
- Handles AC (clear), DEL (delete), and = (calculate) buttons

#### 4. **Keyboard Support**

```javascript
document.addEventListener('keydown', (e) => {
    // Number keys (0-9) and decimal
    if (e.key >= '0' && e.key <= '9') {
        calculator.appendNumber(e.key);
        e.preventDefault();
    } else if (e.key === '.') {
        calculator.appendNumber(e.key);
        e.preventDefault();
    }
    
    // Operator keys
    switch (e.key) {
        case '+':
            calculator.chooseOperation('+');
            break;
        case '-':
            calculator.chooseOperation('-');
            break;
        case '*':
            calculator.chooseOperation('×');  // Convert * to ×
            break;
        case '/':
            calculator.chooseOperation('÷');  // Convert / to ÷
            break;
    }
    
    // Special keys
    if (e.key === 'Enter' || e.key === '=') {
        calculator.compute();
    }
    if (e.key === 'Backspace') {
        calculator.delete();
    }
    if (e.key === 'Escape') {
        calculator.clear();
    }
});
```

**Keyboard Mappings:**

| Key | Action |
|-----|--------|
| 0-9 | Append number |
| . | Add decimal |
| + | Addition |
| - | Subtraction |
| * | Multiplication (× symbol) |
| / | Division (÷ symbol) |
| Enter or = | Calculate |
| Backspace | Delete last digit |
| Escape | Clear all |

#### 5. **Visual Keyboard Feedback**

```javascript
document.addEventListener('keydown', (e) => {
    const buttonMap = {
        '0': '[data-number="0"]',
        '+': '[data-operator="+"]',
        // ... more mappings
    };
    
    const selector = buttonMap[e.key];
    if (selector) {
        const button = document.querySelector(selector);
        if (button) {
            button.style.transform = 'translateY(0)';
        }
    }
});
```
- Adds visual feedback when keys are pressed
- Buttons animate as if they're being clicked
- Improves user experience for keyboard users

---

## 🚀 How to Use

1. **Open in Browser**
   - Double-click `calculator.html` or open with your browser

2. **Mouse Input**
   - Click number buttons to enter digits
   - Click operators to select operation
   - Click "=" to calculate result
   - Click "AC" to clear all
   - Click "DEL" to remove last digit

3. **Keyboard Input**
   - Type numbers directly (0-9, .)
   - Press `+`, `-`, `*`, `/` for operations
   - Press `Enter` or `=` to calculate
   - Press `Backspace` to delete
   - Press `Escape` to clear

---

## 📱 Responsive Design

The calculator is fully responsive:
- **Desktop**: Full-sized buttons and display
- **Tablet**: Optimized spacing and touch targets
- **Mobile**: Adjusted font sizes and padding for smaller screens

---

## 🔧 Browser Compatibility

- ✅ Chrome/Edge (Latest)
- ✅ Firefox (Latest)
- ✅ Safari (Latest)
- ✅ Mobile Browsers (iOS Safari, Chrome Mobile)

---

## 📈 Potential Enhancements

1. **History Log**: Display previous calculations
2. **Scientific Functions**: Square root, power, trigonometry
3. **Dark Mode**: Toggle between light and dark themes
4. **Unit Converter**: Convert between currencies or measurements
5. **Local Storage**: Save calculation history
6. **Themes**: Multiple color schemes to choose from

---

## 📝 License

Free to use and modify for personal or commercial projects.

---

## 👨‍💻 Developer Notes

The calculator is built with Object-Oriented JavaScript principles:
- **Encapsulation**: All calculator logic is contained in the Calculator class
- **Separation of Concerns**: HTML (structure), CSS (styling), JS (logic) are separate
- **DRY Principle**: Code reusability with event listener loops
- **Progressive Enhancement**: Works with keyboard and mouse input

This design makes the calculator easy to maintain and extend with new features.

